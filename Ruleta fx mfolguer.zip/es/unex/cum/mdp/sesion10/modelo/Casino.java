package es.unex.cum.mdp.sesion10.modelo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/*
 * Clase Casino donde se crean las partidas, se registran los usuarios, y se lleva a cabo toda logica del juego
 * Tiene un atributo float caja, guarda la cantidad monetaria de cada casino.
 */
public class Casino implements Serializable {

	private static final long serialVersionUID = 1L;
	protected ArrayList<Estadistica> estadisticas;
	protected Map<String, Usuario> usuarios;
	protected Map<Date, Partida> partidas;
	protected float caja;

	/*
	 * Constructor por defecto
	 */
	public Casino() {
		this.caja = 1000000;
		this.estadisticas = new ArrayList<Estadistica>();
		this.usuarios = new HashMap<String, Usuario>();
		this.partidas = new HashMap<Date, Partida>();
	}

	/*
	 * Constructor parametrizado
	 */
	public Casino(float caja) {
		this.caja = caja;
		this.estadisticas = new ArrayList<Estadistica>();
		this.usuarios = new HashMap<String, Usuario>();
		this.partidas = new HashMap<Date, Partida>();
	}

	/*
	 * Metodo getUsuarios, metodo getter que nos sirve para obtener los usuarios.
	 * Retorna la coleccion (Map) de usuarios
	 */
	public Map<String, Usuario> getUsuarios() {
		return this.usuarios;
	}

	/*
	 * Metodo getPartidas, metodo getter que nos sirve para obtener los partidas.
	 * Retorna la coleccion (Map) de partidas
	 */
	public Map<Date, Partida> getPartidas() {
		return this.partidas;
	}

	/*
	 * Metodo getCaja, metodo getter que nos sirve para obtener el atributo caja de
	 * Casino. Retorna el valor del atributo caja de tipo float
	 */
	public float getCaja() {
		return this.caja;
	}

	public void setCaja(float c) {
		this.caja = c;
	}

	/*
	 * Metodo register, metodo que sirve para a�adir un usuario a la coleccion de
	 * usuarios, controlamos si la lista esta vacia y si el usuario ya esta
	 * incluido. Retorna true o false segun si se ha a�adido el usuario a la
	 * coleccion
	 */
	public boolean register(String nick, String name, String password, float monedero) {

		Usuario u = new Usuario(nick, name, password, monedero);

		if (usuarios.isEmpty()) {
			usuarios.put(u.getNombre(), u);
			return true;
		}

		if (usuarios.get(u.getNombre()) == null) {
			usuarios.put(u.getNombre(), u);
			return true;
		}

		if (!usuarios.containsKey(u.getNombre())) {
			usuarios.put(u.getNombre(), u);
			return true;
		}

		return false;
	}

	/*
	 * Metodo login, metodo que sirve para loguear a un usuario ya registrado,
	 * controlamos si la lista de usuarios esta vacia y si el usuario que
	 * introducimos no existe, en estos casos lanzamos una excepcion, si se loguea
	 * devolvemos el usuario
	 * 
	 * 
	 * Retorna el usuario logueado
	 */
	public Usuario login(String nombre, String pass) throws UsuarioNoAutenticado {
		Usuario u = null;

		if (usuarios.isEmpty()) {
			// usuarionoautenticado
			throw new UsuarioNoAutenticado();
		}

		if (usuarios.containsKey(nombre)) {
			u = usuarios.get(nombre);
			if (u.getPassword().equals(pass)) {
				return u;
			} else {
				throw new UsuarioNoAutenticado();
			}
		} else {
			throw new UsuarioNoAutenticado();

		}

	}

	/*
	 * Metodo addMonedero, metodo que sirve para a�adir dinero a un usuario, le
	 * pasamos el nick y el password y vemos si esta registrado y controlamos si la
	 * lista esta vacia, al realizarse la transaccion de dinero a�adimos un
	 * movimiento. Retornamos un booleano true o false dependiendo si se ha a�adido
	 * correctamente el dinero.
	 */
	public boolean addMonedero(String nombre, String pass, float monedero) {

		if (usuarios.isEmpty()) {
			return false;
		}

		if (usuarios.containsKey(nombre)) {
			Usuario u = usuarios.get(nombre);
			if (u.getPassword().equals(pass)) {
				u.setMonedero(u.getMonedero() + monedero);

				Movimiento m = new Movimiento("addMonedero", u.getMonedero(), monedero, new Date());
				u.addMovimiento(m);
				return true;
			}
		}

		return false;

	}

	/*
	 * Metodo crearPartida, metodo que sirve para crear una partida utilizando la
	 * factoeia mesa definida en partida, la cual crea una mesa y la inicializa con
	 * todos los atributos, al crearse la partida se a�ade a la coleccion de
	 * partidas.
	 * 
	 */
	public Partida crearPartida(String tipo, Date fecha, float caja, float p) {
		this.caja = this.caja - caja;// Para crear una partida le restamos a la caja del casino el valor monetario
		// que le introducimos a la partida
		int id = partidas.size() + 1;
		Partida partida = null;
		switch (tipo) {

		case ("MesaClasicaHS"):
			partida = new PartidaClasica(tipo, id, fecha, caja, p);

			break;

		case ("MesaEuropeaAL"):
			partida = new PartidaEuropea(tipo, id, fecha, caja, p);

			break;

		case ("MesaAmericanaHM"):
			partida = new PartidaAmericana(tipo, id, fecha, caja, p);

			break;
		default:
			// arrojar exepcion?
			partida = null;
			break;
		}

		// obtener id partidas.size()+1
		partidas.put(fecha, partida);
		return partida;

	}

	/*
	 * Metodo adherirseNumero, llamamos al metodo adherirseNumero de partidas solo
	 * que controlamos el logueo del usuario.
	 */
	public NumeroTablero adherirseNumero(String nombre, String password, Date d, String numero) {
		if (usuarios.containsKey(nombre)) {
			Usuario u;
			u = usuarios.get(nombre);
			if (u.getPassword().equals(password)) {
				Partida p;
				// usaremos la �ltima partida
				p = partidas.get(d);// partidas.get(this);
				return p.adherirseNumero(numero, u, d);

			}
		}
		return null;
	}

	/*
	 * Metodo jugar, recibimos una fecha, consultamos que exista dicha partida,
	 * controlamos con el atributo isJugada de Partida si la partida se ha jugado(
	 * la bola ha sido lanzada) en caso de que no haya sido jugada, se llama al
	 * metodo jugar de partida y se actualiza el atributo isJugado de dicha partida
	 * a true.
	 */
	public Reparto jugar(Date d) {
		Partida p = consultarPartida(d);

		if (p.isJugado() == false) {
			p.setJugado(true);

			Reparto r = p.jugar();// devuelve objeto tipo reparto el cual utilizaremos para devolverlo y saber el
			// valor de cada atributo de la partida
			caja = ((r.getCaja() + r.getRecaudacion()) - r.getResultado()) + caja;// los ingresos de la partida p se
			// a�aden a la caja del casino

			return r;
		}
		return null;
	}

	/*
	 * Metodo jugar, recibimos una fecha, consultamos que exista dicha partida,
	 * controlamos con el atributo isJugada de Partida si la partida se ha jugado(
	 * la bola ha sido lanzada) en caso de que no haya sido jugada, se llama al
	 * metodo jugar de partida y se actualiza el atributo isJugado de dicha partida
	 * a true, utilizamos el string numero para establecer el resultado de la
	 * partida(valor de la bola)
	 */
	public Reparto jugar(Date d, String numero) {
		Partida p = consultarPartida(d);

		if (p.isJugado() == false) {
			p.setJugado(true);

			Reparto r = p.jugar(numero);
			caja = ((r.getCaja() + r.getRecaudacion()) - r.getResultado()) + caja;

			return r;
		}
		return null;
	}

	/*
	 * Metodo consultarPartida, sirve para devolver la partida introduciendo una
	 * fecha determinada, controlamos si esta dicha partida en esa fecha.
	 */
	public Partida consultarPartida(Date d) {
		Partida p = null;

		if (partidas.containsKey(d)) {
			p = partidas.get(d);
		}
		return p;

	}

	/*
	 * Metodo getEstadisticas, metodo getter que nos sirve para obtener la lista de
	 * estadisticas. Retorna la lista de estadisticas
	 */
	public ArrayList<Estadistica> getEstadisticas() {

		if (estadisticas.isEmpty()) {// controlamos si esta vacia, en caso de que lo este a�adimos estadistica
			addEstadisticas();
		}
		return this.estadisticas;
	}

	/*
	 * Metodo getEstadisticaNumero, metodo getter para obtener la estadistica de un
	 * objeto tipo tablero, el cual identificaremos su valor con el atributo numero.
	 * Le pasamos por parametro el "numero" del cual queremos obtener la estadistica
	 */
	public Estadistica getEstadisticaNumero(String numero) {

		Estadistica e = null;

		Iterator it2 = getEstadisticas().iterator();
		while (it2.hasNext()) {
			e = (Estadistica) it2.next();
			if (e.getNumero().equals(numero)) {
				return e;
			}
		}
		return null;
	}

	/*
	 * Metodo addEstadisticas, este metodo recorre el mapa de usuarios, cada usuario
	 * contiene una lista de apuestas, las cuales revisaremos para contabilizarlas
	 * 
	 * 
	 */
	public void addEstadisticas() {

		int vecesApostadas = 0;
		int vecesGanado = 0;
		float precioGanado = 0;
		int vaRojo = 0;
		int vgRojo = 0;
		float pgRojo = 0;
		int vaNegro = 0;
		int vgNegro = 0;
		float pgNegro = 0;
		int vaPar = 0;
		int vgPar = 0;
		float pgPar = 0;
		int vaImpar = 0;
		int vgImpar = 0;
		float pgImpar = 0;

		String valor;
		// Este for se utiliza para poder acceder a los numerosTablero de la lista de
		// apuestas de cada usuario
		for (int i = 1; i <= 37; i++) {
			valor = Integer.toString(i);
			if (i == 36) {
				valor = "0";

			}
			if (i == 37) {
				valor = "00";

			}
			vecesApostadas = 0;
			vecesGanado = 0;
			precioGanado = 0;
			for (Usuario u : usuarios.values()) {

				Iterator it2 = u.apuestas.iterator();
				while (it2.hasNext()) {
					Apuesta a = (Apuesta) it2.next();

					if (a.getNt().getValor().equals(valor)) {

						vecesApostadas = vecesApostadas + 1;

					}
					if (a.getNt().getValor().equals(valor) && a.partida.getBolaGanadora().equals(valor)) {

						vecesGanado = vecesGanado + 1;
						precioGanado = a.partida.porNumero * a.getNt().precio + precioGanado;

					}

				}
			}
			Estadistica e = new Estadistica(valor, vecesApostadas, vecesGanado, precioGanado);
			estadisticas.add(e);
		}
		// Mediante este for contabilzaremos las apuestas de cada usuario hechas a Rojo,
		// Negro,Par,Impar
		for (Usuario u : usuarios.values()) {

			Iterator it3 = u.apuestas.iterator();
			while (it3.hasNext()) {
				Apuesta a = (Apuesta) it3.next();

				if (a.getNt().getValor().equals("ROJO")) {

					vaRojo = vaRojo + 1;
					if (a.partida.mesa.getNumeroRuleta(a.partida.getBolaGanadora()).color.name().equals("ROJO")) {
						if (vgRojo < 1) {
							vgRojo = vgRojo + 1;
						}
						pgRojo = a.partida.porColor * a.getNt().precio + pgRojo;

					}
				}

				else if (a.getNt().getValor().equals("NEGRO")) {

					vaNegro = vaNegro + 1;
					if (a.partida.mesa.getNumeroRuleta(a.partida.getBolaGanadora()).color.name().equals("NEGRO")) {
						if (vgNegro < 1) {
							vgNegro = vgNegro + 1;
						}
						pgNegro = a.partida.porColor * a.getNt().precio + pgNegro;

					}
				} else if (a.getNt().getValor().equals("PAR")) {

					vaPar = vaPar + 1;
					if (a.partida.mesa.getNumeroRuleta(a.partida.getBolaGanadora()).ParImpar.name().equals("PAR")) {

						if (vgPar < 1) {
							vgPar = vgPar + 1;
						}
						pgPar = a.partida.porParImpar * a.getNt().precio + pgPar;

					}
				} else if (a.getNt().getValor().equals("IMPAR")) {

					vaImpar = vaImpar + 1;

					if (a.partida.mesa.getNumeroRuleta(a.partida.getBolaGanadora()).ParImpar.name().equals("IMPAR")) {

						if (vgImpar < 1) {
							vgImpar = vgImpar + 1;
						}
						pgImpar = a.partida.porParImpar * a.getNt().precio + pgImpar;

					}
				}

			}
		}
		Estadistica rojo = new Estadistica("ROJO", vaRojo, vgRojo, pgRojo);
		estadisticas.add(rojo);
		Estadistica negro = new Estadistica("NEGRO", vaNegro, vgNegro, pgNegro);
		estadisticas.add(negro);
		Estadistica par = new Estadistica("PAR", vaPar, vgPar, pgPar);
		estadisticas.add(par);
		Estadistica impar = new Estadistica("IMPAR", vaImpar, vgImpar, pgImpar);
		estadisticas.add(impar);

	}

	/*
	 * Metodo setEstadisticas, metodo setter el cual modificamos la lista de
	 * estadisticas Le pasamos por parametro la nueva lista a asignar
	 */
	public void setEstadisticas(ArrayList<Estadistica> e) {
		this.estadisticas = e;

	}

	/*
	 * Metodo el cual ordena las estadisticas en funcion de los atributos de
	 * estadistica
	 */
	public void verRanking() {
		Collections.sort(estadisticas, new ComparatorEstadisticaApostado());
		// Collections.sort(c.getEstadisticas(),new ComparatorEstadisticaNumGanado());
		// Collections.sort(c.getEstadisticas(),new EstadisticaDineroGanado());
	}

	public void cargarMovimientos(String string) {

		BufferedReader br = null;
		try {
			br = new BufferedReader(new InputStreamReader(new FileInputStream(string)));
			String line = null;
			int cont = 0;

			while ((line = br.readLine()) != null) { // Leo l�nea a l�nea
				// divido la l�nea por cada : que presenta un nombre:dni:edad
				String[] split = line.split(":");
				Date fecha = new SimpleDateFormat("dd/MM/yyyy").parse(split[3]);
				Movimiento m = new Movimiento(split[0], Float.parseFloat(split[1]), Float.parseFloat(split[2]), fecha);
				usuarios.get(split[0]).addMovimiento(m);
			}
			br.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}

	public void salvarMovimientos(String string) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
		BufferedWriter br = null;
		try {
			br = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(string)));
			for (Usuario u : usuarios.values()) {

				if (u.getHistorico() == null) {

				} else {
					Iterator it3 = u.getHistorico().iterator();
					while (it3.hasNext()) {
						Movimiento m = (Movimiento) it3.next();
						// � :idUsuario:info:monederoactual:valor:fecha
						String fecha = sdf.format(m.getFecha());
						br.write(u.getNombre() + ":" + m.getInfo() + ":" + m.getMonederoActual() + ":" + m.getValor()
								+ ":" + fecha+"\n");
					}
				}
			}
			br.close();
		} catch (Exception ex) {
			ex.printStackTrace();

		}
	}
}
