package es.unex.cum.mdp.sesion10.modelo;

/*
 * Interface IMesaClasica
 * Consta de dos artibutos para saber el numero de casillas que utilizara
 * Hereda de la interface Mesa
 */
public interface IMesaClasica extends IMesa {

	static final int MINVALOR = 1;
	static final int MAXVALOR = 35;

}
