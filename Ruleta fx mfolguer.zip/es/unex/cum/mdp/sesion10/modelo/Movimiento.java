package es.unex.cum.mdp.sesion10.modelo;

import java.io.Serializable;
import java.util.Date;

/* Clase Movimiento, clase base formada por los atributos info, valor, monederoActual y fecha.
 * 
 * 
 */
public class Movimiento implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	protected String info;
	protected float monederoActual;
	protected float valor;
	protected Date fecha;

	/*
	 * Constructor parametrizado
	 */
	public Movimiento(String info, float monederoActual, float valor, Date fecha) {
		this.info = info;
		this.monederoActual = monederoActual;
		this.valor = valor;
		this.fecha = fecha;
	}

	/*
	 * Metodo getInfo, metodo getter para obtener el atributo info de Movimiento
	 * Retornamos el atributo info de tipo String
	 * 
	 */
	public String getInfo() {
		return info;
	}

	/*
	 * Metodo setInfo, metodo setter para modificar el atributo info de Movimiento
	 * Le pasamos por parametro el atributo info a asignar
	 * 
	 */
	public void setInfo(String info) {
		this.info = info;
	}

	/*
	 * Metodo getMonederoActual, metodo getter para obtener el atributo
	 * monederoActual de Movimiento Retornamos el atributo moenderoActual de tipo
	 * float
	 * 
	 */
	public float getMonederoActual() {
		return monederoActual;
	}

	/*
	 * Metodo setMonederoActual, metodo setter para modificar el atributo
	 * monederoActual de Movimiento Le pasamos por parametro el atributo
	 * monederoActual a asignar
	 * 
	 */
	public void setMonederoActual(float monederoActual) {
		this.monederoActual = monederoActual;
	}

	/*
	 * Metodo getValor, metodo getter para obtener el atributo valor de Movimiento
	 * Retornamos el atributo valor de tipo float
	 * 
	 */
	public float getValor() {
		return valor;
	}

	/*
	 * Metodo setValor, metodo setter para modificar el atributo valor de Movimiento
	 * Le pasamos por parametro el atributo valor a asignar
	 * 
	 */
	public void setValor(float valor) {
		this.valor = valor;
	}

	/*
	 * Metodo getFecha, metodo getter para obtener el atributo fecha de Movimiento
	 * Retornamos el atributo fecha de tipo Date
	 * 
	 */
	public Date getFecha() {
		return fecha;
	}

	/*
	 * Metodo setFecha, metodo setter para modificar el atributo fecha de Movimiento
	 * Le pasamos por parametro el atributo fecha a asignar
	 * 
	 */
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((fecha == null) ? 0 : fecha.hashCode());
		result = prime * result + ((info == null) ? 0 : info.hashCode());
		result = prime * result + Float.floatToIntBits(monederoActual);
		result = prime * result + Float.floatToIntBits(valor);
		return result;
	}

	/*
	 * Metodo equals, sirve para comparar si dos objetos son iguales Le pasamos por
	 * parametro el objeto a comparar El valor de retorno es un booleano, true o
	 * false
	 * 
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Movimiento other = (Movimiento) obj;
		if (fecha == null) {
			if (other.fecha != null)
				return false;
		} else if (!fecha.equals(other.fecha))
			return false;
		if (info == null) {
			if (other.info != null)
				return false;
		} else if (!info.equals(other.info))
			return false;
		if (Float.floatToIntBits(monederoActual) != Float.floatToIntBits(other.monederoActual))
			return false;
		if (Float.floatToIntBits(valor) != Float.floatToIntBits(other.valor))
			return false;
		return true;
	}

	/*
	 * Metodo toString, por el cual obtenemos todos los atributos El valor de
	 * retorno es un String con la informacion de Movimiento
	 * 
	 */
	@Override
	public String toString() {
		return "Movimiento [info=" + info + ", monederoActual=" + monederoActual + ", valor=" + valor + ", fecha="
				+ fecha + "]";
	}

}
