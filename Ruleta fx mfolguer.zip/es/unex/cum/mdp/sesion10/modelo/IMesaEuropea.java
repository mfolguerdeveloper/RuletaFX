package es.unex.cum.mdp.sesion10.modelo;

/*
 * Interface IMesaEuropea
 * Consta de dos artibutos para saber el numero de casillas que utilizara
 * Hereda de la interface Mesa
 */
public interface IMesaEuropea extends IMesa {
	static final int MINVALOR = 1;
	static final int MAXVALOR = 36;
}
