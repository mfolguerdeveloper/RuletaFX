package es.unex.cum.mdp.sesion10.modelo;

import java.io.Serializable;

/*
 * Clase Reparto 
 */
public class Reparto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private float caja, recaudacion, resultado, repartoNumero, repartoColor, repartoPI;;
	private int numApuestas, numNumero, numColor, numPI;

	public float getCaja() {
		return caja;
	}

	/*
	 * Costructor por defecto
	 */
	public Reparto() {

		this.caja = 0.0f;
		this.recaudacion = 0.0f;
		this.resultado = 0.0f;
		this.repartoNumero = 0.0f;
		this.repartoColor = 0.0f;
		this.repartoPI = 0.0f;
		this.numApuestas = 0;
		this.numNumero = 0;
		this.numColor = 0;
		this.numPI = 0;
	}

	/*
	 * Costructor parametrizado
	 */
	public Reparto(float caja, float recaudacion, float resultado, float repartoNumero, float repartoColor,
			float repartoPI, int numApuestas, int numNumero, int numColor, int numPI) {
		super();
		this.caja = caja;
		this.recaudacion = recaudacion;
		this.resultado = resultado;
		this.repartoNumero = repartoNumero;
		this.repartoColor = repartoColor;
		this.repartoPI = repartoPI;
		this.numApuestas = numApuestas;
		this.numNumero = numNumero;
		this.numColor = numColor;
		this.numPI = numPI;
	}

	/*
	 * Metodo para cambiar el valor del atributo caja por parametros
	 */
	public void setCaja(float caja) {
		this.caja = caja;
	}

	/*
	 * Metodo para recuperar el valor del atributo Recaudacion
	 */
	public float getRecaudacion() {
		return recaudacion;
	}

	/*
	 * Metodo para cambiar el valor del atributo Recaudacion por parametros
	 */
	public void setRecaudacion(float recaudacion) {
		this.recaudacion = recaudacion;
	}

	/*
	 * Metodo para recuperar el valor del atributo Resultado
	 */
	public float getResultado() {
		return resultado;
	}

	/*
	 * Metodo para cambiar el valor del atributo Resultado por parametros
	 */
	public void setResultado(float resultado) {
		this.resultado = resultado;
	}

	/*
	 * Metodo para recuperar el valor del atributo RepartoNumero
	 */
	public float getRepartoNumero() {
		return repartoNumero;
	}

	/*
	 * Metodo para cambiar el valor del atributo RepartoNumero por parametros
	 */
	public void setRepartoNumero(float repartoNumero) {
		this.repartoNumero = repartoNumero;
	}

	/*
	 * Metodo para recuperar el valor del atributo RepartoColor
	 */
	public float getRepartoColor() {
		return repartoColor;
	}

	/*
	 * Metodo para cambiar el valor del atributo RepartoColor por parametros
	 */
	public void setRepartoColor(float repartoColor) {
		this.repartoColor = repartoColor;
	}

	/*
	 * Metodo para recuperar el valor del atributo RepartoPi
	 */
	public float getRepartoPI() {
		return repartoPI;
	}

	/*
	 * Metodo para cambiar el valor del atributo RepartoNumeroPI por parametros
	 */
	public void setRepartoPI(float repartoPI) {
		this.repartoPI = repartoPI;
	}

	/*
	 * Metodo para recuperar el valor del atributo NumApuestas
	 */
	public int getNumApuestas() {
		return numApuestas;
	}

	/*
	 * Metodo para cambiar el valor del atributo NumApuestas por parametros
	 */
	public void setNumApuestas(int numApuestas) {
		this.numApuestas = numApuestas;
	}

	/*
	 * Metodo para recuperar el valor del atributo NumNumero
	 */
	public int getNumNumero() {
		return numNumero;
	}

	/*
	 * Metodo para cambiar el valor del atributo NumNumero por parametros
	 */
	public void setNumNumero(int numNumero) {
		this.numNumero = numNumero;
	}

	/*
	 * Metodo para recuperar el valor del atributo NumColor
	 */
	public int getNumColor() {
		return numColor;
	}

	/*
	 * Metodo para cambiar el valor del atributo setNumColor por parametros
	 */
	public void setNumColor(int numColor) {
		this.numColor = numColor;
	}

	/*
	 * Metodo para recuperar el valor del atributo NumPI
	 */
	public int getNumPI() {
		return numPI;
	}

	/*
	 * Metodo para cambiar el valor del atributo NumPI por parametros
	 */
	public void setNumPI(int numPI) {
		this.numPI = numPI;
	}

	/*
	 * Metodo que devuelve un String con el valor de cada atributo
	 *
	 */

	@Override
	public String toString() {
		return "Reparto [caja=" + caja + ", recaudacion=" + recaudacion + ", resultado=" + resultado
				+ ", repartoNumero=" + repartoNumero + ", repartoColor=" + repartoColor + ", repartoPI=" + repartoPI
				+ ", numApuestas=" + numApuestas + ", numNumero=" + numNumero + ", numColor=" + numColor + ", numPI="
				+ numPI + "]";
	}

	/*
	 * Metodo que genera una formula matematica por cada atributo Sirve para
	 * comparar los valores de los atributos
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Float.floatToIntBits(caja);
		result = prime * result + numApuestas;
		result = prime * result + numColor;
		result = prime * result + numNumero;
		result = prime * result + numPI;
		result = prime * result + Float.floatToIntBits(recaudacion);
		result = prime * result + Float.floatToIntBits(repartoColor);
		result = prime * result + Float.floatToIntBits(repartoNumero);
		result = prime * result + Float.floatToIntBits(repartoPI);
		result = prime * result + Float.floatToIntBits(resultado);
		return result;
	}

	/*
	 * Para comparar dos objetos tipo reparto
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Reparto other = (Reparto) obj;
		if (Float.floatToIntBits(caja) != Float.floatToIntBits(other.caja))
			return false;
		if (numApuestas != other.numApuestas)
			return false;
		if (numColor != other.numColor)
			return false;
		if (numNumero != other.numNumero)
			return false;
		if (numPI != other.numPI)
			return false;
		if (Float.floatToIntBits(recaudacion) != Float.floatToIntBits(other.recaudacion))
			return false;
		if (Float.floatToIntBits(repartoColor) != Float.floatToIntBits(other.repartoColor))
			return false;
		if (Float.floatToIntBits(repartoNumero) != Float.floatToIntBits(other.repartoNumero))
			return false;
		if (Float.floatToIntBits(repartoPI) != Float.floatToIntBits(other.repartoPI))
			return false;
		if (Float.floatToIntBits(resultado) != Float.floatToIntBits(other.resultado))
			return false;
		return true;
	}

}
