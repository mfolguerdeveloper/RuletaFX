package es.unex.cum.mdp.sesion10.modelo;

import java.io.Serializable;

/*
 * Enumeracion de atributos para la clase Numero
 */
public enum Color implements Serializable {

	NOCOLOR, ROJO, NEGRO, VERDE,
}
