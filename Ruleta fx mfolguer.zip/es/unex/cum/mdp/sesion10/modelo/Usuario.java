package es.unex.cum.mdp.sesion10.modelo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;

/* Clase Usuario, clase base formada por los atributos fecha, valor y resultado.
 * Tiene una relacion unaria con EstadisticaJugador
 * Tiene dos relaciones naria: con Movimiento y Apuesta
 */
public class Usuario implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	protected String nick;
	protected String nombre;
	protected String password;
	protected float monedero;
	protected EstadisticaJugador ej;
	transient  ArrayList<Movimiento> historico;
	protected ArrayList<Apuesta> apuestas;

	// @Override

	/*
	 * Constructor parametrizado
	 */

	public Usuario(String nick, String nombre, String password, float monedero) {
		this.nick = nick;
		this.nombre = nombre;
		this.password = password;
		this.monedero = monedero;
		this.ej = new EstadisticaJugador();
		this.historico = new ArrayList<Movimiento>();
		this.apuestas = new ArrayList<Apuesta>();
	}

	/*
	 * Constructor por defecto
	 */

	public Usuario() {
		this.nick = "";
		this.nombre = "";
		this.password = "";
		this.monedero = 0F;
		this.ej = new EstadisticaJugador();
		this.historico = new ArrayList<Movimiento>();
		this.apuestas = new ArrayList<Apuesta>();
	}

	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((nick == null) ? 0 : nick.hashCode());
		result = prime * result + ((password == null) ? 0 : password.hashCode());
		return result;
	}

	/*
	 * Metodo equals, sirve para comparar si dos objetos son iguales Le pasamos por
	 * parametro el objeto a comparar El valor de retorno es un booleano, true o
	 * false
	 * 
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Usuario other = (Usuario) obj;
		if (nick == null) {
			if (other.nick != null)
				return false;
		} else if (!nick.equals(other.nick))
			return false;
		if (password == null) {
			if (other.password != null)
				return false;
		} else if (!password.equals(other.password))
			return false;
		return true;
	}

	/*
	 * Metodo getNick, metodo getter para obtener el atributo nick de Usuario
	 * Retornamos el atributo nick de tipo String
	 * 
	 */
	public String getNick() {
		return nick;
	}

	/*
	 * Metodo setNick, metodo setter para modificar el atributo nick de Usuario Le
	 * pasamos por parametro el atributo nick a asignar
	 * 
	 */
	public void setNick(String nick) {
		this.nick = nick;
	}

	/*
	 * Metodo getNombre, metodo getter para obtener el atributo nombre de Usuario
	 * Retornamos el atributo nombre de tipo String
	 * 
	 */
	public String getNombre() {
		return nombre;
	}

	/*
	 * Metodo setNombre, metodo setter para modificar el atributo nombre de Usuario
	 * Le pasamos por parametro el atributo nombre a asignar
	 * 
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	/*
	 * Metodo getPassword, metodo getter para obtener el atributo password de
	 * Usuario Retornamos el atributo password de tipo String
	 * 
	 */
	public String getPassword() {
		return password;
	}

	/*
	 * Metodo setPassword, metodo setter para modificar el atributo password de
	 * Usuario Le pasamos por parametro el atributo password a asignar
	 * 
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/*
	 * Metodo getMonedero, metodo getter para obtener el atributo monedero de
	 * Usuario Retornamos el atributo monedero de tipo float
	 * 
	 */
	public float getMonedero() {
		return monedero;
	}

	/*
	 * Metodo setMonedero, metodo setter para modificar el atributo monedero de
	 * Usuario Le pasamos por parametro el atributo monedero a asignar
	 * 
	 */
	public void setMonedero(float monedero) {
		this.monedero = monedero;
	}

	/*
	 * Metodo getEj, metodo getter para obtener el objeto EstadisticaJugador
	 * Retornamos el objeto EstadisticaJugador
	 * 
	 */
	public EstadisticaJugador getEj() {
		return this.ej;
	}

	/*
	 * Metodo setEj, metodo setter para modificar el objeto EstadisticaJugador Le
	 * pasamos por parametro el objeto EstadisticaJugador a asignar
	 * 
	 */
	public void setEj(EstadisticaJugador ej) {
		this.ej = ej;
	}

	/*
	 * Metodo getHistorico, metodo getter para obtener el Arraylist de Movimientos
	 * Retornamos historico, que es la lista de movimientos
	 * 
	 */
	public ArrayList<Movimiento> getHistorico() {
		return this.historico;
	}

	/*
	 * Metodo getApuestas, metodo getter para obtener el Arraylist de Apuestas
	 * Retornamos apuestas, que es la lista de apuestas
	 * 
	 */
	public ArrayList<Apuesta> getApuestas() {
		return this.apuestas;
	}

	/*
	 * Metodo add para a�adir un movimiento al historico de movimientos
	 */
	public void addMovimiento(Movimiento m) {
		if(historico==null) {
			this.historico = new ArrayList<Movimiento>();	
		}
		historico.add(m);
		
	}

	/*
	 * Metodo para mostrar el historico de movimientos
	 */
	public void mostrarHistorico() {

		Movimiento m;

		Iterator<Movimiento> it = historico.iterator();
		while (it.hasNext()) {
			m = it.next();
			System.out.println(m.toString());
		}

	}
}
