package es.unex.cum.mdp.sesion10.modelo;

import java.io.Serializable;

/*
 * Clase numero: clase basica la cual se utilizara como fundamento de 
 * cada casilla(con sus propiedades correspondientes) implementadas en el casino 
 * Consta de dos String: valor para saber el valor de cada casilla(2, 3, Rojo, Impar)
 * imagen la cual se utilizara ellaimplementcion grafica
 * Y dos enumeraciones Color :para determinar el color de cada casilla
 * y ParImpar para determinar si el valor de cada casilla es Par Imapr o nada
 */
public class Numero implements Serializable  {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	protected String valor;
	protected String imagen;
	protected Color color;
	protected ParImpar ParImpar;

	/*
	 * Constructor por defecto
	 */
	public Numero() {
		this.valor = "0.0F";
		this.imagen = "0.0F";
		this.color = Color.NOCOLOR;
		this.imagen = "0.0F";
		this.ParImpar = ParImpar.NADA;
	}

	/*
	 * Cosntructor parametrizado
	 */
	public Numero(String valor, Color color, String imagen, ParImpar ParImpar) {
		this.valor = valor;
		this.imagen = imagen;
		this.color = color;
		this.imagen = null;
		this.ParImpar = ParImpar;
	}

	/*
	 * Para obtener el valor del atributo Valor
	 */
	public String getValor() {
		return valor;
	}

	public void setValor(String valor) {
		this.valor = valor;
	}

	/*
	 * Para obtener el valor del atributo Imagen
	 */
	public String getImagen() {
		return imagen;
	}

	public void setImagen(String imagen) {
		this.imagen = imagen;
	}

	/*
	 * Para obtener el valor del atributo color
	 */
	public Color getColor() {
		return color;
	}

	public void setColor(Color color) {
		this.color = color;
	}

	/*
	 * Para obtener el valor del atributo ParImpar
	 */
	public ParImpar getParImpar() {
		return ParImpar;
	}

	/*
	 * Metodo para cambiar el valor del atributo ParImpar por parametros
	 */
	public void setParImpar(ParImpar parImpar) {
		ParImpar = parImpar;
	}

	/*
	 * Para obtener el valor del atributos de numero
	 */
	@Override
	public String toString() {
		return "  valor= " + valor  + ", color= " + color + ",  ParImpar= " + ParImpar ;
	}

	/*
	 * Sirve para comparar los valores de los atributos
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((ParImpar == null) ? 0 : ParImpar.hashCode());
		result = prime * result + ((color == null) ? 0 : color.hashCode());
		result = prime * result + ((imagen == null) ? 0 : imagen.hashCode());
		result = prime * result + ((valor == null) ? 0 : valor.hashCode());
		return result;
	}

	/*
	 * Para comparar dos objetos tipo numero
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Numero other = (Numero) obj;
		if (ParImpar != other.ParImpar)
			return false;
		if (color != other.color)
			return false;
		if (imagen == null) {
			if (other.imagen != null)
				return false;
		} else if (!imagen.equals(other.imagen))
			return false;
		if (valor == null) {
			if (other.valor != null)
				return false;
		} else if (!valor.equals(other.valor))
			return false;
		return true;
	}

}
