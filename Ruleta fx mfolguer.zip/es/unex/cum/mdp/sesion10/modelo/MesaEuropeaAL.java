package es.unex.cum.mdp.sesion10.modelo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;

/*
 * Clase IMesaAmericanaHM la cual implementa todos los metodos de IMesa y los atributos de IMesaAmericana
 * Tiene un HashSer de NumeroTablero para usar esas casillas  como apuestas
 *  Tiene un HashSer de NumeroRuleta para usar esas casillas  como objeto de la apuesta
 *  Consta de dos atributos precio(el cual se usa para aumentar o disminuir el valor de cada apuesta)y id
 *  numero identificatorio de cada mesa
 */
public class MesaEuropeaAL implements IMesaAmericana , Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	protected ArrayList<NumeroRuleta> ruleta = new ArrayList<NumeroRuleta>();;
	protected ArrayList<NumeroTablero> tablero = new ArrayList<NumeroTablero>();
	protected float precioApuesta;
	protected int id;

	/*
	 * Constructor por defecto de la clase MesaAmericanaHM
	 */
	public MesaEuropeaAL() {
		this.id = 0;
		this.precioApuesta = 0.0f;

	}

	/*
	 * Constructor parametrizado de la clase MesaAmericanaHM
	 */
	public MesaEuropeaAL(int id, float precio) {
		this.id = id;
		this.precioApuesta = precio;

	}

	/*
	 * Metodo crear en cual inicializa los 35 NumeroRuleta de ruleta con sus
	 * atributos correspondientes y los 35+4 NumeroTablero con sus atributos
	 * correspondientes Recibe un float p el cual se usa para aumentar o disminuir
	 * el valor de cada apuesta
	 */
	@Override
	public boolean crear(float p) {

		if (p <= 0) {
			return false;
		}
		String valor;
		Color color = null;
		String imagen = null;
		ParImpar ParImpar = null;
		boolean bola = false;
		precioApuesta = p;

		for (int i = 1; i <= IMesaEuropea.MAXVALOR; i++) {

			valor = Integer.toString(i);
			if (i % 2 == 0) {
				ParImpar = ParImpar.PAR;
			} else {
				ParImpar = ParImpar.IMPAR;
			}

			int c = i % 10;
			int d = i / 10;

			if ((d + c) % 2 == 0) {
				color = color.NEGRO;
			} else {
				color = color.ROJO;
			}

			if (i == 36) {
				valor = "0";
				color = color.VERDE;
				ParImpar = ParImpar.NADA;
			}

			NumeroRuleta nr = new NumeroRuleta(valor, color, imagen, ParImpar, bola);

			ruleta.add(nr);

			color = color.NOCOLOR;
			ParImpar = ParImpar.NADA;
			if (i == 36) {
				valor = "0";
				color = color.VERDE;
				ParImpar = ParImpar.NADA;
			}

			NumeroTablero nt = new NumeroTablero(valor, color, imagen, ParImpar, p);
			tablero.add(nt);

		}

		NumeroTablero PAR = new NumeroTablero("PAR", color.NOCOLOR, imagen, ParImpar.NADA, p);
		tablero.add(PAR);

		NumeroTablero IMPAR = new NumeroTablero("IMPAR", color.NOCOLOR, imagen, ParImpar.NADA, p);
		tablero.add(IMPAR);

		NumeroTablero ROJO = new NumeroTablero("ROJO", color.NOCOLOR, imagen, ParImpar.NADA, p);
		tablero.add(ROJO);

		NumeroTablero NEGRO = new NumeroTablero("NEGRO", color.NOCOLOR, imagen, ParImpar.NADA, p);
		tablero.add(NEGRO);

		return true;
	}

	/*
	 * Metodo por el cual se le pasa un String y un Usuario y devuelve el Numero
	 * tablero con el mismo valor que el String Se usara para hacer apuestas
	 */
	@Override
	public NumeroTablero adherirseNumero(String numero, Usuario u) {
		NumeroTablero nt;
		// recorrer la lista tablero
		Iterator<NumeroTablero> i = tablero.iterator();
		while (i.hasNext()) {
			nt = i.next();
			if (nt.getValor().equals(numero)) {
				return nt;
			}
		}
		// cambiar por la exception
		return null;
	}

	/*
	 * Metodo por el cual se genera un numero aleatorio de los NumeroRuleta
	 * existentes y lo devuelve
	 */
	@Override
	public NumeroRuleta jugar() {

		int n = (int) (Math.random() * ((IMesaEuropea.MAXVALOR + 1) - MINVALOR)) + MINVALOR;
		NumeroRuleta nr = null;
		nr = getNumeroRuleta(String.valueOf(n));
		nr.setBola(true);
		return nr;
	}

	/*
	 * Metodo por el cual se compara un String valor con el valor de los
	 * NumeroRuleta almacenados en ruleta y devuelve el que tiene el mismo valor.
	 * Simula el lanzamiento de la bola en el casino , en el numero que caiga se le
	 * cambiara el atributo bola de false a true
	 */
	@Override
	public NumeroRuleta jugar(String valor) {
		NumeroRuleta nr = null;
		nr = getNumeroRuleta(valor);
		if (nr != null) {
			nr.setBola(true);
		}

		return nr;
	}

	/*
	 * Metodo por el cual se compara un String numero con el valor de los
	 * NumeroRuleta almacenados en ruleta y devuelve el que tiene el mismo valor.
	 * Sirve para comprobar que devuelve el NumeroRuleta con el mismo valor pasado
	 */
	@Override
	public NumeroRuleta getNumeroRuleta(String numero) {
		NumeroRuleta nr;
		// recorrer la lista ruleta

		Iterator<NumeroRuleta> i = ruleta.iterator();
		while (i.hasNext()) {
			nr = i.next();
			if (nr.getValor().equals(numero)) {
				return nr;
			}
		}
		// cambiar por la exception
		return null;
	}

	/*
	 * Metodo por el cual se compara un String numero con el valor de los
	 * NumeroTablero almacenados en tablero y devuelve el que tiene el mismo valor.
	 * Sirve para comprobar que devuelve el NumeroTablero con el mismo valor pasado
	 */
	@Override
	public NumeroTablero getNumeroTablero(String numero) {
		NumeroTablero nt;
		// recorrer la lista tablero
		Iterator<NumeroTablero> i = tablero.iterator();
		while (i.hasNext()) {
			nt = i.next();
			if (nt.getValor().equals(numero)) {
				return nt;
			}
		}
		// cambiar por la exception
		return null;

	}

	/*
	 * Clase que sera utilizada para la implementacion grafica
	 */
	@Override
	public void mostrar() {
		// TODO Auto-generated method stub

	}

	/*
	 * Sivepara mostrar el valor del atributo precio
	 */
	@Override
	public float getPrecioApuesta() {

		return precioApuesta;
	}

	/*
	 * Sirve para modificar el atributo id, pasandole un int por parametros
	 */
	@Override
	public void setId(int id) {
		this.id = id;

	}

	@Override
	public void setPrecioApuesta(float p) {

		this.precioApuesta = p;
	}

}
