package es.unex.cum.mdp.sesion10.modelo;

import java.io.Serializable;
import java.util.Date;
/*
 * Clase en la cual se establece la logica de juego de la PartidaEuropea
 */
public class PartidaClasica extends Partida implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	static final int porColor = 2;
	static final int porParImpar = 2;
	static final int porNumero = 35;

	/*
	 * Constructor por parametros de PartidaClasica que llama al Constructor por
	 * parametros de Partida
	 * 
	 */
	public PartidaClasica(String tipo, int id, Date fecha, float caja, float p) {
		super(tipo, id, fecha, caja, p);
		Partida.porColor = porColor;
		Partida.porParImpar = porParImpar;
		Partida.porNumero = porNumero;

	}

	/*
	 * Metodo el cual a�ade una apuesta al array de apuestas de partida tambien
	 * modifica algunos artibutos del reparto de la partida y de la clase
	 * EstadisticaJugador perteneciente de usuario el cual realiza la apuesta
	 * 
	 */
	@Override
	public NumeroTablero adherirseNumero(String numero, Usuario u, Date fecha) {

		NumeroTablero nt = null;
		//aqui controlo que el monedero del usuario tenga la cantidad sufisiente de lacasitos para realizar la apuesta

		

			reparto.setNumApuestas(reparto.getNumApuestas() + 1);
			nt = mesa.adherirseNumero(numero, u);

			u.ej.setNumJugadas(u.ej.getNumJugadas() + 1);
			reparto.setRecaudacion(nt.getPrecio() + reparto.getRecaudacion());

			

			if (numero.equals("ROJO") || numero.equals("NEGRO")) {

				u.ej.setNumColor(u.ej.getNumColor() + 1);
			}
			if (numero.equals("PAR") || numero.equals("IMPAR")) {

				u.ej.setNumPI(u.ej.getNumPI() + 1);
			}
			u.ej.setNumNumero(u.ej.getNumJugadas() - (u.ej.getNumPI() + u.ej.getNumColor()));
			//creamos un objeto tipo movimiento y lo a�adimos a el usuario, el cual es un resumen de cada jugada

			Movimiento m = new Movimiento(nt.getValor(), u.getMonedero(), mesa.getPrecioApuesta(), fecha);
			u.addMovimiento(m);


			u.ej.setNumPerdidas(u.ej.getNumPerdidas() + 1);

			float resultado = 0;
			Apuesta a = new Apuesta(fecha, nt.getPrecio(), nt, null, u, resultado);
			a.setPartida(this);
			apuestas.add(a);
			u.apuestas.add(a);

		
		return nt;
	}

	/*
	 * Metodo el cual se utiliza para saber que funciona. Dado a que le pasas un
	 * numero y ese es el que saldra en la tirada de la ruleta Este metodo llama a
	 * repartirPremio y devuelve la clase reparto (la cual contiene informacion de
	 * la partida)
	 * 
	 */
	@Override
	public Reparto jugar(String numero) {
		NumeroRuleta nr = mesa.jugar(numero);
		bolaGanadora = nr.getValor();
		setJugado(true);
		setBolaGanadora(nr.getValor());
		if (nr.isBola()) {

			repartirPremios(nr, nr.getParImpar(), nr.getColor());

		}

		return getReparto();
	}

	/*
	 * Metodo el cual cual crea un numeroRuleta aleatorio utilizando el metodo jugar
	 * de IMesaAmericanaHM y es el que se utilizara para la clase Repartir premio.
	 * Devuelve la clase reparto (la cual contiene informacion de la partida)
	 */
	@Override
	public Reparto jugar() {
		NumeroRuleta nr = mesa.jugar();
		bolaGanadora = nr.getValor();
		setJugado(true);
		setBolaGanadora(nr.getValor());
		if (nr.isBola()) {

			repartirPremios(nr, nr.getParImpar(), nr.getColor());

		}

		return getReparto();
	}

	/*
	 * Metodo en el cual se recorre el ArrayList de apuestas y se compara con el
	 * numero ruleta recibido por parametros En este metodo se actualizan algunos
	 * valores de la clase Reparto perteneciente Partida y algunos atributos de
	 * Estadistica Jugador
	 */
	@Override
	public void repartirPremios(NumeroRuleta nr, ParImpar p, Color c) {

		String numero = nr.getValor();

		for (Apuesta i : apuestas) {

			// como con 0 y 00 funcionan como un numero que si se le apuesta consiges premio
						// En la segunda condicion del if controlo que si es un NumeroTablero tipo
						// rojo/negro/par/impar
						// no se meta en la condicion
			if (i.getNt().getValor().equals(numero) && (i.getNt().getColor().equals("NOCOLOR") != true)) {
				// modificamos el valor del atributo de la apuesta i Resultado, segun la partida
				// jugada(tipo de mesa)
				i.setResultado(i.getResultado() + mesa.getPrecioApuesta() * porNumero);
				// modificamos el atributo NumNumero de Reparto sumandole 1 (como un contador)

				reparto.setNumNumero(reparto.getNumNumero() + 1);
				// modificamos el monedero del usuario

				i.getUsuario().setMonedero(mesa.getPrecioApuesta() * porNumero + i.getUsuario().getMonedero());
				reparto.setRepartoNumero(reparto.getRepartoNumero() + (mesa.getPrecioApuesta() * porNumero));// + si es
																												// el
																												// dinero
																												// que
																												// ha
																												// ganado
																												// el
																												// usuario

				reparto.setResultado((mesa.getPrecioApuesta() * porNumero) + reparto.getResultado());
				// a�adir las estadisticas de jugador

				i.getUsuario().ej.setNumGanadas(i.getUsuario().ej.getNumGanadas() + 1);
				i.getUsuario().ej.setNumPerdidas(i.getUsuario().ej.getNumPerdidas() - 1);
				i.getUsuario().ej
						.setDineroGanado(i.getUsuario().ej.getDineroGanado() + (i.getNt().getPrecio() * porNumero));
				//creamos un objeto tipo movimiento y lo a�adimos a el usuario, el cual es un resumen de cada jugada

				Movimiento m = new Movimiento(i.getNt().getValor(), i.getUsuario().getMonedero(),
						mesa.getPrecioApuesta(), new Date());
				i.getUsuario().addMovimiento(m);
			}
			if (i.getNt().getValor().equals(c.name())) {

				i.setResultado(i.getResultado() + mesa.getPrecioApuesta() * porColor);
				reparto.setNumColor(reparto.getNumColor() + 1);
				i.getUsuario().setMonedero(mesa.getPrecioApuesta() * porColor + i.getUsuario().getMonedero());
				reparto.setRepartoColor(reparto.getRepartoColor() + (mesa.getPrecioApuesta() * porColor));

				reparto.setResultado((mesa.getPrecioApuesta() * porColor) + reparto.getResultado());

				i.getUsuario().ej.setNumGanadas(i.getUsuario().ej.getNumGanadas() + 1);
				i.getUsuario().ej.setNumPerdidas(i.getUsuario().ej.getNumPerdidas() - 1);
				i.getUsuario().ej
						.setDineroGanado(i.getUsuario().ej.getDineroGanado() + i.getNt().getPrecio() * porColor);

				Movimiento m = new Movimiento(i.getNt().getValor(), i.getUsuario().getMonedero(),
						mesa.getPrecioApuesta(), new Date());
				i.getUsuario().addMovimiento(m);

			}
			if (i.getNt().getValor().equals(p.name())) {

				i.setResultado(i.getResultado() + mesa.getPrecioApuesta() * porParImpar);
				reparto.setNumPI(reparto.getNumPI() + 1);
				i.getUsuario().setMonedero(i.getNt().getPrecio() * porParImpar + i.getUsuario().getMonedero());
				reparto.setRepartoPI(reparto.getRepartoPI() + (mesa.getPrecioApuesta() * porParImpar));

				reparto.setResultado((mesa.getPrecioApuesta() * porParImpar) + reparto.getResultado());

				i.getUsuario().ej.setNumGanadas(i.getUsuario().ej.getNumGanadas() + 1);
				i.getUsuario().ej.setNumPerdidas(i.getUsuario().ej.getNumPerdidas() - 1);
				i.getUsuario().ej
						.setDineroGanado(i.getUsuario().ej.getDineroGanado() + i.getNt().getPrecio() * porParImpar);

				Movimiento m = new Movimiento(i.getNt().getValor(), i.getUsuario().getMonedero(),
						mesa.getPrecioApuesta(), new Date());
				i.getUsuario().addMovimiento(m);
			}
			// if(i.getNt().getValor().equals("0")) en caso de que haga algo especial
			// if(i.getNt().getValor().equals("00")) en caso de que haga algo especial

			i.getUsuario().ej.setDineroPerdido(i.getNt().getPrecio() + i.getUsuario().ej.getDineroPerdido());

		}

	}
}
