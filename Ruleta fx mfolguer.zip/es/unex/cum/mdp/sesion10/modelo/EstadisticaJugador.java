package es.unex.cum.mdp.sesion10.modelo;

import java.io.Serializable;

/* Clase EstadisticaJugador, clase base formada por los atributos numJugadas, numGanadas, numPerdidas, dineroGanado,dineroPerdido,numColor,numPI,numNumero.
 * 
 * 
 */
public class EstadisticaJugador implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	protected int numJugadas;
	protected int numGanadas;
	protected int numPerdidas;
	protected float dineroGanado;
	protected float dineroPerdido;
	protected int numColor;
	protected int numPI;
	protected int numNumero;

	/*
	 * Constructor por defecto
	 */
	public EstadisticaJugador() {
		this.numJugadas = 0;
		this.numGanadas = 0;
		this.numPerdidas = 0;
		this.dineroGanado = 0;
		this.dineroPerdido = 0;
		this.numColor = 0;
		this.numPI = 0;
		this.numNumero = 0;
	}

	/*
	 * Constructor parametrizado
	 */
	public EstadisticaJugador(int numJugadas, int numGanadas, int numPerdidas, float dineroGanado, float dineroPerdido,
			int numColor, int numPI, int numNumero) {
		this.numJugadas = numJugadas;
		this.numGanadas = numGanadas;
		this.numPerdidas = numPerdidas;
		this.dineroGanado = dineroGanado;
		this.dineroPerdido = dineroPerdido;
		this.numColor = numColor;
		this.numPI = numPI;
		this.numNumero = numNumero;
	}

	/*
	 * Metodo getNumJugadas, metodo getter para obtener el atributo numJugadas de
	 * EstadisticaJugador Retornamos el atributo numJugadas de tipo int
	 * 
	 */
	public int getNumJugadas() {
		return numJugadas;
	}

	/*
	 * Metodo setNumJugadas, metodo setter para modificar el atributo numJugadas de
	 * EstadisticaJugador Le pasamos por parametro el atributo numJugadas a asignar
	 * 
	 */
	public void setNumJugadas(int numJugadas) {
		this.numJugadas = numJugadas;
	}

	/*
	 * Metodo getNumJugadas, metodo getter para obtener el atributo NumGanadas de
	 * EstadisticaJugador Retornamos el atributo numGanadas de tipo int
	 * 
	 */
	public int getNumGanadas() {
		return numGanadas;
	}

	/*
	 * Metodo setNumGanadas, metodo setter para modificar el atributo numGanadas de
	 * EstadisticaJugador Le pasamos por parametro el atributo numGanadas a asignar
	 * 
	 */
	public void setNumGanadas(int numGanadas) {
		this.numGanadas = numGanadas;
	}

	/*
	 * Metodo getNumPerdidas, metodo getter para obtener el atributo NumPerdidas de
	 * EstadisticaJugador Retornamos el atributo numPerdidas de tipo int
	 * 
	 */
	public int getNumPerdidas() {
		return numPerdidas;
	}

	/*
	 * Metodo setNumPerdidas, metodo setter para modificar el atributo numPerdidas
	 * de EstadisticaJugador Le pasamos por parametro el atributo numPerdidas a
	 * asignar
	 * 
	 */
	public void setNumPerdidas(int numPerdidas) {
		this.numPerdidas = numPerdidas;
	}

	/*
	 * Metodo getDineroGanado, metodo getter para obtener el atributo dineroGanado
	 * de EstadisticaJugador Retornamos el atributo dineroGanado de tipo float
	 * 
	 */
	public float getDineroGanado() {
		return dineroGanado;
	}

	/*
	 * Metodo setDineroGanado, metodo setter para modificar el atributo dineroGanado
	 * de EstadisticaJugador Le pasamos por parametro el atributo dineroGanado a
	 * asignar
	 * 
	 */
	public void setDineroGanado(float dineroGanado) {
		this.dineroGanado = dineroGanado;
	}

	/*
	 * Metodo getDineroPerdido, metodo getter para obtener el atributo dineroPerdido
	 * de EstadisticaJugador Retornamos el atributo dineroPerdido de tipo float
	 * 
	 */
	public float getDineroPerdido() {
		return dineroPerdido;
	}

	/*
	 * Metodo setDineroPerdido, metodo setter para modificar el atributo
	 * dineroPerdido de EstadisticaJugador Le pasamos por parametro el atributo
	 * dineroPerdido a asignar
	 * 
	 */
	public void setDineroPerdido(float dineroPerdido) {
		this.dineroPerdido = dineroPerdido;
	}

	/*
	 * Metodo getNumColor, metodo getter para obtener el atributo numColor de
	 * EstadisticaJugador Retornamos el atributo numColor de tipo int
	 * 
	 */
	public int getNumColor() {
		return numColor;
	}

	/*
	 * Metodo setNumColor, metodo setter para modificar el atributo numColor de
	 * EstadisticaJugador Le pasamos por parametro el atributo numColor a asignar
	 * 
	 */
	public void setNumColor(int numColor) {
		this.numColor = numColor;
	}

	/*
	 * Metodo getNumPI, metodo getter para obtener el atributo numPI de
	 * EstadisticaJugador Retornamos el atributo numColor de tipo int
	 * 
	 */
	public int getNumPI() {
		return numPI;
	}

	/*
	 * Metodo setNumPI, metodo setter para modificar el atributo numPI de
	 * EstadisticaJugador Le pasamos por parametro el atributo numPI a asignar
	 * 
	 */
	public void setNumPI(int numPI) {
		this.numPI = numPI;
	}

	/*
	 * Metodo getNumNumero, metodo getter para obtener el atributo numNumero de
	 * EstadisticaJugador Retornamos el atributo numNumero de tipo int
	 * 
	 */
	public int getNumNumero() {
		return numNumero;
	}

	/*
	 * Metodo setNumNumero, metodo setter para modificar el atributo numNumero de
	 * EstadisticaJugador Le pasamos por parametro el atributo numNumero a asignar
	 * 
	 */
	public void setNumNumero(int numNumero) {
		this.numNumero = numNumero;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Float.floatToIntBits(dineroGanado);
		result = prime * result + Float.floatToIntBits(dineroPerdido);
		result = prime * result + numColor;
		result = prime * result + numGanadas;
		result = prime * result + numJugadas;
		result = prime * result + numNumero;
		result = prime * result + numPI;
		result = prime * result + numPerdidas;
		return result;
	}

	/*
	 * Metodo equals, sirve para comparar si dos objetos son iguales Le pasamos por
	 * parametro el objeto a comparar El valor de retorno es un booleano, true o
	 * false
	 * 
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EstadisticaJugador other = (EstadisticaJugador) obj;
		if (Float.floatToIntBits(dineroGanado) != Float.floatToIntBits(other.dineroGanado))
			return false;
		if (Float.floatToIntBits(dineroPerdido) != Float.floatToIntBits(other.dineroPerdido))
			return false;
		if (numColor != other.numColor)
			return false;
		if (numGanadas != other.numGanadas)
			return false;
		if (numJugadas != other.numJugadas)
			return false;
		if (numNumero != other.numNumero)
			return false;
		if (numPI != other.numPI)
			return false;
		if (numPerdidas != other.numPerdidas)
			return false;

		return true;
	}

	/*
	 * Metodo toString, por el cual obtenemos todos los atributos El valor de
	 * retorno es un String con la informacion de EstadisitcaJugador
	 * 
	 */
	@Override
	public String toString() {
		return "EstadisticaJugador [numJugadas=" + numJugadas + ", numGanadas=" + numGanadas + ", numPerdidas="
				+ numPerdidas + ", dineroGanado=" + dineroGanado + ", dineroPerdido=" + dineroPerdido + ", numColor="
				+ numColor + ", numPI=" + numPI + ", numNumero=" + numNumero + "]";
	}

}
