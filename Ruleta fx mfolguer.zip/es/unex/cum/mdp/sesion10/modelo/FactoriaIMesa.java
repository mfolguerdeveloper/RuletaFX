package es.unex.cum.mdp.sesion10.modelo;

import java.io.Serializable;

/*
 * Metodo factoria mesa el cual se utiliza para crear las mesa e inicializarlas utilizando 
 * un switch case el cual contiene la informacion necesaria
 * 
 */
public class FactoriaIMesa  implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/*
	 * Solo contempla estos tres tipos de implementacion de la mesa
	 */
	public static IMesa getIMesa(String tipo, int id, float p) {
		IMesa m;

		switch (tipo) {

		case ("MesaClasicaHS"):
			m = new MesaClasicaHS(id, p);// crea la mesa
			m.crear(p);// inicializa los valores de las listas de mesa(tablero,ruleta)
			break;// sale de la condicion

		case ("MesaEuropeaAL"):
			m = new MesaEuropeaAL(id, p);
			m.crear(p);
			break;

		case ("MesaAmericanaHM"):
			m = new MesaAmericanaHM(id, p);
			m.crear(p);

			break;
		default:

			m = null;// en caso de no recibir un tipo igual a los establecidos se devolvera null
			break;
		}

		return m;
	}
}
