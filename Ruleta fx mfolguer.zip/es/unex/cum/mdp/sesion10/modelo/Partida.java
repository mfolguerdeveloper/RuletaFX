package es.unex.cum.mdp.sesion10.modelo;

import java.util.Date;
import java.io.Serializable;
import java.util.ArrayList;

public abstract class Partida extends FactoriaIMesa implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	static int porColor = 2;
	static int porParImpar = 2;
	static int porNumero = 35;
	protected int id;
	protected Date fecha;
	protected boolean jugado;
	protected String bolaGanadora=null;
	protected IMesa mesa;
	protected ArrayList<Apuesta> apuestas;
	protected Reparto reparto;
	protected float precio;



	/*
	 * Constructor por defecto de Partida
	 */
	public Partida() {
		this.reparto = new Reparto();
		this.id = 0;
		this.fecha = new Date();
		reparto.setCaja(10);
		this.mesa = getIMesa("MesaClasicaHS", 1, 1);
		this.apuestas = new ArrayList<Apuesta>();
		this.precio=0;
		
	}

	/*
	 * Constructor por parametros de Partida El cual crea una Mesa utilizando la
	 * FactoriaMesa la cual crea la ruleta y el tablero de apuestas
	 */
	public Partida(String tipo, int id, Date fecha, float caja, float p) {
		this.reparto = new Reparto();
		this.id = id;
		this.fecha = fecha;
		reparto.setCaja(caja);
		this.mesa = getIMesa(tipo, id, p);
		this.apuestas = new ArrayList<Apuesta>();
		this.precio=p;


	}

	/*
	 * Metodo por el cual se implementa y explica en cada una de las clases
	 * derivadas
	 */
	public abstract NumeroTablero adherirseNumero(String numero, Usuario u, Date fecha);

	/*
	 * Metodo por el cual se implementa y explica en cada una de las clases
	 * derivadas
	 */
	public abstract Reparto jugar(String numero);

	/*
	 * Metodo por el cual se implementa y explica en cada una de las clases
	 * derivadas
	 */
	public abstract Reparto jugar();

	/*
	 * Metodo por el cual se implementa y explica en cada una de las clases
	 * derivadas
	 */
	public abstract void repartirPremios(NumeroRuleta nr, ParImpar p, Color c);

	/*
	 * Metodo el cual devuelve el Id de la partida
	 */
	public int getId() {
		return id;
	}

	/*
	 * Metodo el cual modifica el Id de la partida por parametros
	 */
	public void setId(int id) {
		this.id = id;
	}

	/*
	 * Metodo el cual devuelve la fecha en formato Date de la partida
	 */
	public Date getFecha() {
		return fecha;
	}

	/*
	 * Metodo el cual modifica la fecha en formato Date de la partida por parametros
	 */
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	/*
	 * Metodo el nos da el atributo el cual indica si se ha lanzado la Bola partida
	 * por parametros
	 */
	public boolean isJugado() {
		return jugado;
	}

	/*
	 * Metodo el cual modifica el atributo que indica si se ha lanzado la Bola
	 * partida por parametros
	 */
	public void setJugado(boolean jugado) {
		this.jugado = jugado;
	}

	/*
	 * Metodo el cual nos indica que numero ha salido en la tirada de la ruleta
	 */
	public String getBolaGanadora() {
		return bolaGanadora;
	}

	/*
	 * Metodo el cual modifica por parametros el numero que ha salido en la tirada
	 * de la ruleta
	 */
	public void setBolaGanadora(String bolaGanadora) {
		this.bolaGanadora = bolaGanadora;
	}

	/*
	 * Metodo el cual nos indica la mesa con la que estamos jugando
	 */
	public IMesa getMesa() {

		return mesa;
	}

	/*
	 * Metodo el cual modifica la mesa con la que estamos jugando
	 */
	public void setMesa(IMesa mesa) {
		this.mesa = mesa;
	}

	/*
	 * Metodo el cual nos devuelve el array de apuestas
	 */
	public ArrayList<Apuesta> getApuestas() {
		return apuestas;
	}

	/*
	 * Metodo el cual modifica por parametros el array de apuestas
	 */
	public void setApuestas(ArrayList<Apuesta> apuestas) {
		this.apuestas = apuestas;
	}

	/*
	 * Metodo el cual nos devuelve el la clase reparto
	 */
	public Reparto getReparto() {
		return reparto;
	}

	/*
	 * Metodo el cual modifica toda la clase reparto
	 */
	public void setReparto(Reparto reparto) {
		this.reparto = reparto;
	}

	/*
	 * Metodo el cual nos devuelve el atributo que contiene el valor de la apuesta a
	 * color
	 */
	public static int getPorcolor() {
		return porColor;
	}

	/*
	 * Metodo el cual nos devuelve el atributo que contiene el valor de la apuesta a
	 * ParImpar
	 */
	public static int getPorparimpar() {
		return porParImpar;
	}

	/*
	 * Metodo el cual nos devuelve el atributo que contiene el valor de la apuesta a
	 * un numero
	 */
	public static int getPornumero() {
		return porNumero;
	}

	public String getTipoMesa() {
		return mesa.getClass().getSimpleName();
	}

	

	public float getPrecio() {
		return precio;
	}

	public void setPrecio(float precio) {
		this.precio = precio;
	}
	
	
	

}
