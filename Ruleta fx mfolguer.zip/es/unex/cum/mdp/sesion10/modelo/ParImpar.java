package es.unex.cum.mdp.sesion10.modelo;

import java.io.Serializable;

/*
 * Enumeracion de atributos para la clase Numero
 */
public enum ParImpar implements Serializable  {

	NADA, PAR, IMPAR,
}