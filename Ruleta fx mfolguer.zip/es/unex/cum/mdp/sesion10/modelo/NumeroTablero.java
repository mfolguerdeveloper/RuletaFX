package es.unex.cum.mdp.sesion10.modelo;

import java.io.Serializable;
import java.util.ArrayList;

/*
 * Clase NumeroTablero: usada para representar las casillas y valores a los que se puede apostar
 * hereda de la clase Numero.
 * Contiene una lista de la clase Apuesta y un float precio que indicara el valor monetario de cada casilla
 */
public class NumeroTablero extends Numero implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	protected float precio;
	private ArrayList<Apuesta> lista;

	/*
	 * constructor por defecto
	 */
	public NumeroTablero() {
		super();
		lista = new ArrayList<Apuesta>();
		this.precio = 0;
	}

	/*
	 * Cosntructor paremetrizado
	 */
	public NumeroTablero(String valor, Color color, String imagen, ParImpar ParImpar, float precio) {
		super(valor, color, imagen, ParImpar);
		this.precio = precio;
		lista = new ArrayList<Apuesta>();
	}

	/*
	 * metodo heredado para obtener el atributo valor de Numero
	 */
	public String getValor() {
		return super.getValor();
	}

	/*
	 * Metodo para obtener el atributo Precio
	 */
	public float getPrecio() {
		return precio;
	}

	/*
	 * Metodo para modificar el atributo Precio
	 */
	public void setPrecio(float precio) {
		this.precio = precio;
	}

	/*
	 * Metodo para recuperar la lista de apuestas
	 */
	public ArrayList<Apuesta> getLista() {
		return lista;
	}

	/*
	 * Metodo para establecer una lista de apuestas
	 */
	public void setLista(ArrayList<Apuesta> apuestas) {
		lista = apuestas;
	}

	/*
	 * Metodo para saber los valores de los atributos de NumeroTablero usando la
	 * herencia del metodo toString de la clase padre
	 * 
	 */
	@Override
	public String toString() {
		return "NumeroTablero [ " + super.toString() + " ]";
	}

	/*
	 * Sirve para comparar los valores de los atributos
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((lista == null) ? 0 : lista.hashCode());
		result = prime * result + Float.floatToIntBits(precio);
		return result;
	}

	/*
	 * Sirve para comparar(saber si son el mismo) dos objetos tipo NumeroTablero
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		NumeroTablero other = (NumeroTablero) obj;
		if (lista == null) {
			if (other.lista != null)
				return false;
		} else if (!lista.equals(other.lista))
			return false;
		if (Float.floatToIntBits(precio) != Float.floatToIntBits(other.precio))
			return false;
		return true;
	}

}
