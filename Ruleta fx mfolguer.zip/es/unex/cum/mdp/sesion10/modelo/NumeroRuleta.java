package es.unex.cum.mdp.sesion10.modelo;

import java.io.Serializable;

/*
 * Clase Numero Ruleta : Hace referencia a cada casilla de la ruleta con sus propiedades(atributos correspondientes)
 * Contiene un nuevo atributo bola que sirve para identificar si el NumeroRuleta es el ganador de la tirada
 * 
 */
public class NumeroRuleta extends Numero implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private boolean bola;

	/*
	 * Constructor por defecto
	 */
	public NumeroRuleta() {

		super();
		this.bola = false;
	}

	/*
	 * Constructor parametrizado
	 */
	public NumeroRuleta(String valor, Color color, String imagen, ParImpar ParImpar, boolean bola) {
		super(valor, color, imagen, ParImpar);
		this.bola = bola;
	}

	/*
	 * metodo heredado para obtener el atributo valor de Numero
	 */
	public String getValor() {
		return super.getValor();
	}

	/*
	 * Metodo para obtener el valor del atributo bola
	 */
	public boolean isBola() {
		return bola;
	}

	/*
	 * Metodo para cambiar el valor del atributo bola por parametros
	 */
	public void setBola(boolean bola) {
		this.bola = bola;
	}

	/*
	 * Metodo para saber los valores de los atributos de NUmero Ruleta usando la
	 * herencia del metodo toString de la clase padre
	 * 
	 */
	@Override
	public String toString() {
		return " NumeroRuleta [bola=" + bola + super.toString() + "]";
	}

	/*
	 * Sirve para comparar los valores de los atributos
	 */

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + (bola ? 1231 : 1237);
		return result;
	}
	/*
	 * Sirve para comparar(saber si son el mismo) dos objetos tipo NumeroRuleta
	 */

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		NumeroRuleta other = (NumeroRuleta) obj;
		if (bola != other.bola)
			return false;
		return true;
	}

}
