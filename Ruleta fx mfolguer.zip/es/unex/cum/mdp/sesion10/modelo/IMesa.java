package es.unex.cum.mdp.sesion10.modelo;

import java.io.Serializable;

/* Interfaz de IMesa, se definen los metodos para usarse en sus derivadas.
 * 
 */
public interface IMesa  {
	public boolean crear(float p);

	public NumeroTablero adherirseNumero(String numero, Usuario u);

	public NumeroRuleta jugar();

	public NumeroRuleta jugar(String valor);

	public NumeroRuleta getNumeroRuleta(String numero);

	public NumeroTablero getNumeroTablero(String numero);

	public void mostrar();

	public float getPrecioApuesta();

	public void setId(int id);

	public void setPrecioApuesta(float p);

}
