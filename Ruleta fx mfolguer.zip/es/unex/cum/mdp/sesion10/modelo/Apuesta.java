package es.unex.cum.mdp.sesion10.modelo;

import java.io.Serializable;
import java.util.Date;

/* Clase Apuesta, clase base formada por los atributos fecha, valor y resultado.
 * Tiene tres relaciones unaria: con NumeroTablero, con Usuario y con Partida.
 * 
 */
public class Apuesta implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	protected Date fecha;
	protected float valor;
	protected NumeroTablero nt;
	protected Usuario usuario;
	protected float resultado;
	protected Partida partida;


	/*
	 * Constructor parametrizado
	 */

	public Apuesta(Date fecha, float valor, NumeroTablero nt, Partida p, Usuario us, float resultado) {
		this.fecha = fecha;
		this.valor = valor;
		this.usuario = us;
		this.resultado = resultado;
		this.nt = nt;
		this.partida = p;
	}
	/*
	 * Constructor por defecto
	 */

	public Apuesta() {
		this.fecha = new Date();
		this.valor = 0.0f;
		this.usuario = new Usuario();
		this.resultado = 0.0f;
		this.nt = null;

	}

	/*
	 * Metodo getFecha, metodo getter para obtener el atributo fecha de Apuesta
	 * Retornamos el atributo fecha de tipo Date
	 * 
	 */
	public Date getFecha() {
		return fecha;
	}

	/*
	 * Metodo setFecha, metodo setter para modificar el atributo fecha de Apuesta Le
	 * pasamos por parametro el atributo fecha a asignar
	 * 
	 */
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	/*
	 * Metodo getValor, metodo getter para obtener el atributo valor de Apuesta
	 * Retornamos el atributo Valor de tipo float
	 * 
	 */
	public float getValor() {
		return valor;
	}

	/*
	 * Metodo setValor, metodo setter para modificar el atributo valor de Apuesta Le
	 * pasamos por parametro el atributo valor a asignar
	 * 
	 */
	public void setValor(float valor) {
		this.valor = valor;
	}

	/*
	 * Metodo getUsuario, metodo getter para obtener el objeto Usuario Retornamos el
	 * objeto Usuario
	 * 
	 */
	public Usuario getUsuario() {
		return usuario;
	}

	/*
	 * Metodo setUsuario, metodo setter para modificar el objeto Usuario Le pasamos
	 * por parametro el objeto Usuario a asignar
	 * 
	 */
	public void setUsuario(Usuario us) {
		this.usuario = us;
	}

	/*
	 * Metodo getResultado, metodo getter para obtener el atributo resultado de
	 * Apuesta Retornamos el atributo resultado de tipo float
	 * 
	 */
	public float getResultado() {
		return resultado;
	}

	/*
	 * Metodo setResultado, metodo setter para modificar el atributo resultado de
	 * Apuesta Le pasamos por parametro el atributo resultado a asignar
	 * 
	 */
	public void setResultado(float resultado) {
		this.resultado = resultado;
	}

	/*
	 * Metodo getNt, metodo getter para obtener el objeto NumeroTablero Retornamos
	 * el objeto NumeroTablero
	 * 
	 */
	public NumeroTablero getNt() {
		return nt;
	}

	
	/*
	 * Metodo setNt, metodo setter para modificar el objeto NumeroTablero Le pasamos
	 * por parametro el objeto NumeroTablero a asignar
	 * 
	 */
	public void setNt(NumeroTablero nt) {
		this.nt = nt;
	}

	/*
	 * Metodo getPartida, metodo getter para obtener el objeto Partida Retornamos el
	 * objeto Partida
	 * 
	 */
	public Partida getPartida() {
		return partida;
	}

	/*
	 * Metodo setPartida, metodo setter para modificar el objeto Partida Le pasamos
	 * por parametro el objeto Partida a asignar
	 * 
	 */
	public void setPartida(Partida partida) {
		this.partida = partida;
		
	}

	public String getNtValor() {
		return nt.getValor();
	}

	
	
	public String getTipoMesa() {
		return 	partida.getTipoMesa();
	}

	

	
	public String getGanada() {
		String g="";
		if(partida.getBolaGanadora()!=null) {
		if((getResultado()>0)&&partida.getBolaGanadora().equals("")==false) {
			g= "ganada";
		}
		
		if((getResultado()==0)&&partida.getBolaGanadora().equals("")==false){
			g= "perdida";
			}
		}else {
			g="No jugada";
		}
		return g;
	}

	

	public String getGanadorMesa() {
		return partida.getBolaGanadora();
	}

	
	/*
	 * Metodo toString, por el cual obtenemos todos los atributos El valor de
	 * retorno es un String con la informacion de Apuesta
	 * 
	 */
	


	@Override
	public String toString() {
		return "Apuesta [fecha=" + fecha + ", valor=" + valor + ", nt=" + nt + ", usuario=" + usuario + ", resultado="
				+ resultado + ", partida=" + partida + "]";
	}

	

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((fecha == null) ? 0 : fecha.hashCode());
		result = prime * result + ((nt == null) ? 0 : nt.hashCode());
		result = prime * result + ((partida == null) ? 0 : partida.hashCode());
		result = prime * result + Float.floatToIntBits(resultado);
		result = prime * result + ((usuario == null) ? 0 : usuario.hashCode());
		result = prime * result + Float.floatToIntBits(valor);
		return result;
	}

	/*
	 * Metodo equals, sirve para comparar si dos objetos son iguales Le pasamos por
	 * parametro el objeto a comparar El valor de retorno es un booleano, true o
	 * false
	 * 
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Apuesta other = (Apuesta) obj;
		if (fecha == null) {
			if (other.fecha != null)
				return false;
		} else if (!fecha.equals(other.fecha))
			return false;
		if (nt == null) {
			if (other.nt != null)
				return false;
		} else if (!nt.equals(other.nt))
			return false;
		if (partida == null) {
			if (other.partida != null)
				return false;
		} else if (!partida.equals(other.partida))
			return false;
		if (Float.floatToIntBits(resultado) != Float.floatToIntBits(other.resultado))
			return false;
		if (usuario == null) {
			if (other.usuario != null)
				return false;
		} else if (!usuario.equals(other.usuario))
			return false;
		if (Float.floatToIntBits(valor) != Float.floatToIntBits(other.valor))
			return false;
		return true;
	}

}
