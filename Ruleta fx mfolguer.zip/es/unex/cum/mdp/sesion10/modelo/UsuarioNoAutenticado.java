package es.unex.cum.mdp.sesion10.modelo;

import java.io.Serializable;

/*
 * Clase UsuarioNoAuntenticado, esta clase la usaremos para devolver una excepcion si se produce error al auntenticar al Usuario
 */
public class UsuarioNoAutenticado  extends Exception implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public UsuarioNoAutenticado()
	{
		super();
	}
	
	public UsuarioNoAutenticado(String msg)
	{
		super(msg);
		
	}
}

