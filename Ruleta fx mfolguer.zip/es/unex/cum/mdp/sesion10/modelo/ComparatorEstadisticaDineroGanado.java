package es.unex.cum.mdp.sesion10.modelo;

import java.util.Comparator;
/*
 * Clase utilizada para comparar los atributos precioGanado de dos objetos tipo Estadistica 
 * usando la interface Comparator y el metodo compareTo "el cual devuelve un int (-1) si nuestra instancia es menor
 *  que la instancia pasada por par�metro
 * cero (0) si ambas instancias son iguales
 * un valor positivo mayor que cero (1) si nuestra instancia es mayor"
 * mediante este metodo se va ordenando la lista de objetos tipo Estadistica segun el valor de precioGanado
 */
public class ComparatorEstadisticaDineroGanado implements Comparator<Estadistica>{

	@Override
	public int compare(Estadistica o1, Estadistica o2) {
		Estadistica e1 = (Estadistica)o1;              
		Estadistica e2 = (Estadistica)o2;     
		Float vpe1=e1.getPrecioGanado();
		Float vpe2=e2.getPrecioGanado();
		return vpe2.compareTo(vpe1);
	}


}
