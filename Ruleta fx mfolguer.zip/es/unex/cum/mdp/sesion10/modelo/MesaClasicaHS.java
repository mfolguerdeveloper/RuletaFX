package es.unex.cum.mdp.sesion10.modelo;

import java.io.Serializable;
import java.util.HashSet;

/*
 * Clase IMesaClasicaHS la cual implementa todos los metodos de IMesa y los atributos de IMesaClasica
 * Tiene un HashSer de NumeroTablero para usar esas casillas  como apuestas
 *  Tiene un HashSer de NumeroRuleta para usar esas casillas  como objeto de la apuesta
 *  Consta de dos atributos precio(el cual se usa para aumentar o disminuir el valor de cada apuesta)y id
 *  numero identificatorio de cada mesa
 */
public class MesaClasicaHS implements IMesaClasica , Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	protected HashSet<NumeroTablero> tablero = new HashSet<NumeroTablero>();
	protected HashSet<NumeroRuleta> ruleta = new HashSet<NumeroRuleta>();
	protected float precioApuesta;
	protected int id;

	/*
	 * Constructor por defecto de la clase MesaClasicaHS
	 */
	public MesaClasicaHS() {
		this.id = 0;
		this.precioApuesta = 0.0f;

	}

	/*
	 * Constructor parametrizado de la clase MesaClasicaHS
	 */
	public MesaClasicaHS(int id, float precio) {
		this.id = id;
		this.precioApuesta = precio;

	}

	/*
	 * Metodo crear en cual inicializa los 35 NumeroRuleta de ruleta con sus
	 * atributos correspondientes y los 35+4 NumeroTablero con sus atributos
	 * correspondientes Recibe un float p el cual se usa para aumentar o disminuir
	 * el valor de cada apuesta
	 */

	@Override
	public boolean crear(float p) {

		if (p <= 0) {
			return false;
		}
		String valor;
		Color color = null;
		String imagen = null;
		ParImpar ParImpar = null;
		boolean bola = false;
		precioApuesta = p;

		for (int i = 1; i <= MAXVALOR; i++) {

			valor = Integer.toString(i);

			if (i % 2 == 0) {
				ParImpar = ParImpar.PAR;
			} else {
				ParImpar = ParImpar.IMPAR;
			}

			int c = i % 10;
			int d = i / 10;

			if ((d + c) % 2 == 0) {
				color = color.NEGRO;
			} else {
				color = color.ROJO;
			}

			NumeroRuleta nr = new NumeroRuleta(valor, color, imagen, ParImpar, bola);
			ruleta.add(nr);// a�ade un duplicado en la primera iteracion falla el hascode de numeroruleta
			// devueve mal

			color = color.NOCOLOR;
			ParImpar = ParImpar.NADA;
			NumeroTablero nt = new NumeroTablero(valor, color, imagen, ParImpar, p);
			tablero.add(nt);

		}

		NumeroTablero PAR = new NumeroTablero("PAR", color.NOCOLOR, imagen, ParImpar.NADA, p);
		tablero.add(PAR);

		NumeroTablero IMPAR = new NumeroTablero("IMPAR", color.NOCOLOR, imagen, ParImpar.NADA, p);
		tablero.add(IMPAR);

		NumeroTablero ROJO = new NumeroTablero("ROJO", color.NOCOLOR, imagen, ParImpar.NADA, p);
		tablero.add(ROJO);

		NumeroTablero NEGRO = new NumeroTablero("NEGRO", color.NOCOLOR, imagen, ParImpar.NADA, p);
		tablero.add(NEGRO);

		return true;
	}

	/*
	 * Metodo por el cual se le pasa un String y un Usuario y devuelve el Numero
	 * tablero con el mismo valor que el String Se usara para hacer apuestas
	 */
	@Override
	public NumeroTablero adherirseNumero(String numero, Usuario u) {
		if (numero != null) {
			for (NumeroTablero i : tablero) {

				if (i.getValor().equals(numero)) {
					// a�adir una apuesta a la lista de apuesta de nuemrotablero?
					// Apuesta a=(new Date(),);Date fecha, float valor, Usuario us, float resultado
					return i;

				}
			}
		}

		return null;

	}

	/*
	 * Metodo por el cual se genera un numero aleatorio de los NumeroRuleta
	 * existentes y lo devuelve
	 */
	@Override
	public NumeroRuleta jugar() {

		int n = (int) (Math.random() * ((MAXVALOR + 1) - MINVALOR)) + MINVALOR;
		String valor = Integer.toString(n);

		for (NumeroRuleta i : ruleta) {

			if (i.getValor().equals(valor)) {
				i.setBola(true);
				return i;

			}
		}

		return null;
	}

	/*
	 * Metodo por el cual se compara un String valor con el valor de los
	 * NumeroRuleta almacenados en ruleta y devuelve el que tiene el mismo valor.
	 * Simula el lanzamiento de la bola en el casino , en el numero que caiga se le
	 * cambiara el atributo bola de false a true
	 */
	@Override
	public NumeroRuleta jugar(String valor) {

		if (valor != null) {

			for (NumeroRuleta i : ruleta) {

				if (i.getValor().equals(valor)) {
					i.setBola(true);
					return i;

				}
			}
		}
		return null;
	}

	/*
	 * Metodo por el cual se compara un String numero con el valor de los
	 * NumeroRuleta almacenados en ruleta y devuelve el que tiene el mismo valor.
	 * Sirve para comprobar que devuelve el NumeroRuleta con el mismo valor pasado
	 */
	@Override
	public NumeroRuleta getNumeroRuleta(String numero) {

		for (NumeroRuleta i : ruleta) {

			if (i.getValor().equals(numero)) {
				return i;

			}
		}

		return null;
	}

	/*
	 * Metodo por el cual se compara un String numero con el valor de los
	 * NumeroTablero almacenados en tablero y devuelve el que tiene el mismo valor.
	 * Sirve para comprobar que devuelve el NumeroTablero con el mismo valor pasado
	 */
	@Override
	public NumeroTablero getNumeroTablero(String numero) {

		for (NumeroTablero i : tablero) {

			if (i.getValor().equals(numero)) {
				return i;

			}
		}
		return null;
	}

	/*
	 * Clase que sera utilizada para la implementacion grafica
	 */
	@Override
	public void mostrar() {
		// TODO Auto-generated method stub

	}

	/*
	 * Sivepara mostrar el valor del atributo precio
	 */
	@Override
	public float getPrecioApuesta() {

		return precioApuesta;
	}

	/*
	 * Sirve para modificar el atributo id, pasandole un int por parametros
	 */
	@Override
	public void setId(int id) {
		this.id = id;

	}

	@Override
	public void setPrecioApuesta(float p) {

		this.precioApuesta = p;
	}

}
