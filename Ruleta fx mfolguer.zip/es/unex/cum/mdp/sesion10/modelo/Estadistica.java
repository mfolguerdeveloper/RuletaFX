package es.unex.cum.mdp.sesion10.modelo;

import java.io.Serializable;

/* Clase Estadistica, clase base formada por los atributos numero, numVecesApostado, numGanado, precioGanado.
 * 
 * 
 */
public class Estadistica implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String numero;
	private int numVecesApostado;
	private int numGanado;
	private float precioGanado;

	/*
	 * Constructor parametrizado
	 */
	public Estadistica(String numero, int numVecesApostado, int numGanado, float precioGanado) {
		this.numero = numero;
		this.numVecesApostado = numVecesApostado;
		this.numGanado = numGanado;
		this.precioGanado = precioGanado;
	}

	/*
	 * Metodo getNumero, metodo getter para obtener el atributo numero de
	 * Estadistica Retornamos el atributo numero de tipo String
	 * 
	 */
	public String getNumero() {
		return numero;
	}

	/*
	 * Metodo setNumero, metodo setter para modificar el atributo numero de
	 * Estadistica Le pasamos por parametro el atributo numero a asignar
	 * 
	 */
	public void setNumero(String numero) {
		this.numero = numero;
	}

	/*
	 * Metodo getNumVecesApostado, metodo getter para obtener el atributo
	 * numVecesApostado de Estadistica Retornamos el atributo numVecesApostado de
	 * tipo int
	 * 
	 */
	public int getNumVecesApostado() {
		return numVecesApostado;
	}

	/*
	 * Metodo setNumVecesApostado, metodo setter para modificar el atributo
	 * numVecesApsotado de Estadistica Le pasamos por parametro el atributo
	 * numVecesApostado a asignar
	 * 
	 */
	public void setNumVecesApostado(int numVecesApostado) {
		this.numVecesApostado = numVecesApostado;
	}

	/*
	 * Metodo getNumGanado, metodo getter para obtener el atributo numGanado de
	 * Estadistica Retornamos el atributo numGanado de tipo int
	 * 
	 */
	public int getNumGanado() {
		return numGanado;
	}

	/*
	 * Metodo setNumGanado, metodo setter para modificar el atributo numGanado de
	 * Estadistica Le pasamos por parametro el atributo numGanado a asignar
	 * 
	 */
	public void setNumGanado(int numGanado) {
		this.numGanado = numGanado;
	}

	/*
	 * Metodo getPrecioGanado, metodo getter para obtener el atributo precioGanado
	 * de Estadistica Retornamos el atributo precioGanado de tipo float
	 * 
	 */
	public float getPrecioGanado() {
		return precioGanado;
	}

	/*
	 * Metodo setPrecioGanado, metodo setter para modificar el atributo precioGanado
	 * de Estadistica Le pasamos por parametro el atributo precioGanado a asignar
	 * 
	 */
	public void setPrecioGanado(float precioGanado) {
		this.precioGanado = precioGanado;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + numGanado;
		result = prime * result + numVecesApostado;
		result = prime * result + ((numero == null) ? 0 : numero.hashCode());
		result = prime * result + Float.floatToIntBits(precioGanado);
		return result;
	}

	/*
	 * Metodo equals, sirve para comparar si dos objetos son iguales Le pasamos por
	 * parametro el objeto a comparar El valor de retorno es un booleano, true o
	 * false
	 * 
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Estadistica other = (Estadistica) obj;
		if (numGanado != other.numGanado)
			return false;
		if (numVecesApostado != other.numVecesApostado)
			return false;
		if (numero == null) {
			if (other.numero != null)
				return false;
		} else if (!numero.equals(other.numero))
			return false;
		if (Float.floatToIntBits(precioGanado) != Float.floatToIntBits(other.precioGanado))
			return false;
		return true;
	}

	/*
	 * Metodo toString, por el cual obtenemos todos los atributos El valor de
	 * retorno es un String con la informacion de Estadisitca
	 * 
	 */
	@Override
	public String toString() {
		return "Estadistica [numero=" + numero + ", numVecesApostado=" + numVecesApostado + ", numGanado=" + numGanado
				+ ", precioGanado=" + precioGanado + "]";
	}

}
