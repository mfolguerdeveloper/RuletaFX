package es.unex.cum.mdp.sesion10.controlador;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import es.unex.cum.mdp.sesion10.modelo.Partida;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class GirarRuletaControlador {

	public Partida p;
	public Partida getP(){
		return p;
	}
	private MainControlador mc = null;
	
	//Solo el setter, as� se evita que se devuelva
	public void setM(MainControlador mc) {this.mc = mc;}
	
	@FXML
	private TableView<Partida> tblPartidas;

	@FXML
	private TableColumn colTipoMesa;

	@FXML
	private TableColumn colJugada;


	private ObservableList<Partida> partidas;

	
	
	

    @FXML
    void MostrarPartidas(ActionEvent event) {
    	 List<Partida> l=transformarMapaLista(mc.getC().getPartidas()) ;
			partidas = FXCollections.observableList(l);
			tblPartidas.setItems(partidas);

			//He estado probando con esta metodologia para saber el nombre de la clase y como no funcionaba , 
			//cree un atributo String en partida el cual indica el tipo de mesa 
				//Partida p=this.tblPartidas.getSelectionModel().getSelectedItem();
				//System.out.println(p.getClass().getName());

			this.colTipoMesa.setCellValueFactory(new PropertyValueFactory("tipoMesa"));
			this.colJugada.setCellValueFactory(new PropertyValueFactory("jugado"));
			tblPartidas.getColumns().setAll(colTipoMesa, colJugada);
    }

    @FXML
    void GirarRuleta(ActionEvent event) {
		Alert alerta = new Alert(AlertType.INFORMATION);	
    	Partida pa =this.tblPartidas.getSelectionModel().getSelectedItem();
		if(pa!=null) {
			if(pa.isJugado()==false) {
			mc.getC().jugar(pa.getFecha());
			alerta.setContentText("EL RESULTADO ES: "+mc.getC().getPartidas().get(pa.getFecha()).getBolaGanadora());
			alerta.showAndWait();
			}else {
				alerta.setContentText("Esa partida ya ha sido jugada");
				alerta.showAndWait();
			}
			
		
		}
		
    }
	private List<Partida> transformarMapaLista(Map<Date, Partida> map) {

		List<Partida> lista = new ArrayList<Partida>();

		for (Partida p : map.values()) {
			if(p.isJugado()==false) {
			lista.add(p);
			}
		}
		return lista;


	}

}
