package es.unex.cum.mdp.sesion10.controlador;



import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import es.unex.cum.mdp.sesion10.modelo.Casino;
import es.unex.cum.mdp.sesion10.modelo.Partida;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class VerPartidasControlador implements Initializable  {

	public Partida p;
	public Partida getP(){
		return p;
	}
	private MainControlador mc = null;
	
	//Solo el setter, as� se evita que se devuelva
	public void setM(MainControlador mc) {this.mc = mc;}
	
	@FXML
	private TableView<Partida> tblPartidas;

	@FXML
	private TableColumn colTipoMesa;

	@FXML
	private TableColumn colJugada;


	private ObservableList<Partida> partidas;

	
	@FXML
	void VerReparto(ActionEvent event) throws IOException {

		Partida pa =this.tblPartidas.getSelectionModel().getSelectedItem();
		
		if((pa!=null)&&(pa.isJugado()==false)) {
			Alert alerta = new Alert(AlertType.INFORMATION);

			alerta.setContentText(
					"Solo puedes ver el Reparto de las partidas jugadas");
			alerta.showAndWait();
		}
		if((pa!=null)&&(pa.isJugado()==true)) {
			this.p=pa;
			FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("../vistas/VerReparto.fxml"));
			Parent parent = fxmlLoader.load();
			// Se crear el controlador de di�logo y se pasa el controlador principal
			VerRepartoControlador dialogController = fxmlLoader.getController();
			dialogController.setVP(this);
			// Se establece la escena
			System.out.println("tupu");

			Scene scene = new Scene(parent);
			// Se establece el stage
			Stage stage = new Stage();
			stage.initModality(Modality.APPLICATION_MODAL);
			stage.setScene(scene);
			stage.showAndWait();		
		}
		
		}
	

	@Override
	public void initialize(URL url, ResourceBundle rb) {
		
		

	}
	  @FXML
	    void MostrarPartidas(ActionEvent event) {
		  List<Partida> l=transformarMapaLista(mc.getC().getPartidas()) ;
			partidas = FXCollections.observableList(l);
			tblPartidas.setItems(partidas);

			//He estado probando con esta metodologia para saber el nombre de la clase y como no funcionaba , 
			//cree un atributo String en partida el cual indica el tipo de mesa 
				//Partida p=this.tblPartidas.getSelectionModel().getSelectedItem();
				//System.out.println(p.getClass().getName());

			this.colTipoMesa.setCellValueFactory(new PropertyValueFactory("tipoMesa"));
			this.colJugada.setCellValueFactory(new PropertyValueFactory("fecha"));
			tblPartidas.getColumns().setAll(colTipoMesa, colJugada);

	    }
	private void closeStage(ActionEvent event) {
		Node source = (Node) event.getSource();
		Stage stage = (Stage) source.getScene().getWindow();
		stage.close();
	}
	private List<Partida> transformarMapaLista(Map<Date, Partida> map) {

		List<Partida> lista = new ArrayList<Partida>();

		for (Partida p : map.values()) {
			if(p.isJugado()==true) {
			lista.add(p);
			}
		}
		return lista;


	}
}
