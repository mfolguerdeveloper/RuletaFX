package es.unex.cum.mdp.sesion10.controlador;

import java.net.URL;
import java.util.ResourceBundle;

import es.unex.cum.mdp.sesion10.modelo.Usuario;
import es.unex.cum.mdp.sesion10.modelo.UsuarioNoAutenticado;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class LoguearseControlador implements Initializable {
	@FXML
	private TextField nombre;
	@FXML
	private TextField contrase�a;


	private Usuario u=null;
	
	private MainControlador mc = null;
	//Solo el setter, as� se evita que se devuelva
	public void setM(MainControlador mc) {this.mc = mc;}
	
	public Usuario getU() {
		return u;
	}
	@FXML
	void PulsadoCancel(ActionEvent event) {
		closeStage(event);
	}
	@FXML
	void PulsadoOk(ActionEvent event)  {
		
		
		Alert alert3 = new Alert(AlertType.INFORMATION);

			
				try {
					u=mc.getC().login(nombre.getText(), contrase�a.getText());
					if (u!=null) {					
						alert3.setContentText("Se ha iniciado sesion correctamente");
						
					}
				} catch (UsuarioNoAutenticado e) {
					alert3.setContentText("Usuario o conrtrase�a incorrecta");			
				}
				alert3.showAndWait();
			
			closeStage(event);
		
	}
	
	private void closeStage(ActionEvent event) {
		Node source = (Node) event.getSource();
		Stage stage = (Stage) source.getScene().getWindow();
		
		stage.close();
	}
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {

		nombre.setText("");
		contrase�a.setText("");
		
	}
}
