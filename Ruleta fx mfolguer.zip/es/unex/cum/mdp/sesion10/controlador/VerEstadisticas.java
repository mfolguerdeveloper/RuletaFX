package es.unex.cum.mdp.sesion10.controlador;

import java.util.List;

import es.unex.cum.mdp.sesion10.modelo.Apuesta;
import es.unex.cum.mdp.sesion10.modelo.Estadistica;
import es.unex.cum.mdp.sesion10.modelo.Partida;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

public class VerEstadisticas  {

    @FXML
    private TableView<Estadistica> tblEstadisticas;

    @FXML
    private TableColumn colNumero;

    @FXML
    private TableColumn colVecesApostado;

    @FXML
    private TableColumn colVecesGanado;

    @FXML
    private TableColumn colPrecioGanado;

    private ObservableList<Estadistica> estadisticas;

	public Partida p;
	public Partida getP(){
		return p;
	}
	private MainControlador mc = null;
	
	//Solo el setter, as� se evita que se devuelva
	public void setM(MainControlador mc) {this.mc = mc;}
    @FXML
    void MostrarEstadisticas(ActionEvent event) {
    	 List<Estadistica> l=mc.getC().getEstadisticas();
    	 estadisticas = FXCollections.observableList(l);
    	 tblEstadisticas.setItems(estadisticas);

			//He estado probando con esta metodologia para saber el nombre de la clase y como no funcionaba , 
			//cree un atributo String en partida el cual indica el tipo de mesa 
				//Partida p=this.tblPartidas.getSelectionModel().getSelectedItem();
				//System.out.println(p.getClass().getName());

			this.colNumero.setCellValueFactory(new PropertyValueFactory("numero"));
			this.colVecesApostado.setCellValueFactory(new PropertyValueFactory("numVecesApostado"));
			this.colVecesGanado.setCellValueFactory(new PropertyValueFactory("numGanado"));
			this.colPrecioGanado.setCellValueFactory(new PropertyValueFactory("precioGanado"));
			
			tblEstadisticas.getColumns().setAll(colNumero,colVecesApostado, colVecesGanado,colPrecioGanado);
    }

}
