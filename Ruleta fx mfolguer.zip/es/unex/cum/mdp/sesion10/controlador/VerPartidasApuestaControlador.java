package es.unex.cum.mdp.sesion10.controlador;

import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import es.unex.cum.mdp.sesion10.modelo.Casino;
import es.unex.cum.mdp.sesion10.modelo.Partida;
import es.unex.cum.mdp.sesion10.modelo.Usuario;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class VerPartidasApuestaControlador implements Initializable {

	@FXML
	private TableView<Partida> tblPartidas;

	@FXML
	private TableColumn colTipoMesa;
	@FXML
	private TableColumn colJugada;

	@FXML
	private TableColumn colPrecioApuesta;

	@FXML
	private RadioButton nRojo;

	@FXML
	private ToggleGroup Apuesta;

	@FXML
	private RadioButton nNegro;

	@FXML
	private RadioButton nPar;

	@FXML
	private RadioButton nImpar;

	@FXML
	private RadioButton n1;

	@FXML
	private RadioButton n2;

	@FXML
	private RadioButton n3;

	@FXML
	private RadioButton n4;

	@FXML
	private RadioButton n5;

	@FXML
	private RadioButton n6;

	@FXML
	private RadioButton n7;

	@FXML
	private RadioButton n8;

	@FXML
	private RadioButton n9;

	@FXML
	private RadioButton n10;

	@FXML
	private RadioButton n11;

	@FXML
	private RadioButton n12;

	@FXML
	private RadioButton n13;

	@FXML
	private RadioButton n14;

	@FXML
	private RadioButton n15;

	@FXML
	private RadioButton n16;

	@FXML
	private RadioButton n17;

	@FXML
	private RadioButton n18;

	@FXML
	private RadioButton n19;

	@FXML
	private RadioButton n20;

	@FXML
	private RadioButton n21;

	@FXML
	private RadioButton n22;

	@FXML
	private RadioButton n23;

	@FXML
	private RadioButton n24;

	@FXML
	private RadioButton n25;

	@FXML
	private RadioButton n26;

	@FXML
	private RadioButton n27;

	@FXML
	private RadioButton n28;

	@FXML
	private RadioButton n29;

	@FXML
	private RadioButton n30;

	@FXML
	private RadioButton n31;

	@FXML
	private RadioButton n32;

	@FXML
	private RadioButton n33;

	@FXML
	private RadioButton n34;

	@FXML
	private RadioButton n35;

	@FXML
	private RadioButton n0;

	public Casino c=null;


	@FXML
	private RadioButton n00;

	@FXML
	private Label DineroJug;

	private ObservableList<Partida> partidas;

	public Partida p;

	private MainControlador mc = null;

	//Solo el setter, as� se evita que se devuelva
	public void setM(MainControlador mc) {this.mc = mc;}

	@FXML
	void SelecionarMesa(ActionEvent event) {
		Partida pa =this.tblPartidas.getSelectionModel().getSelectedItem();
		if(pa!=null) {

			if(pa.isJugado()==false) {

				this.p=pa;

				n0.setVisible(true);
				n00.setVisible(true);
				if(p.getTipoMesa().equals("MesaEuropeaAL")) {
					n00.setVisible(false);
				}
				if(p.getTipoMesa().equals("MesaClasicaHS")) {
					n0.setVisible(false);
					n00.setVisible(false);
				}
			}else {
				Alert alerta = new Alert(AlertType.INFORMATION);
				alerta.setContentText("Esta partida ya ha sido jugada selecione otra");
				alerta.showAndWait();


			}
		}
	}
	@FXML
	void Apostar(ActionEvent event) {
		Alert alerta = new Alert(AlertType.INFORMATION);

		if(p==null)
		{
			alerta.setContentText("Debes Selecionar una Mesa antes");

		}else {

			String numero="";
			Usuario u=mc.getU();

			if(n1.isSelected()) {
				numero="1";
			}
			if(n2.isSelected()) {
				numero="2";
			}
			if(n3.isSelected()) {
				numero="3";
			}
			if(n4.isSelected()) {
				numero="4";
			}
			if(n5.isSelected()) {
				numero="5";
			}
			if(n6.isSelected()) {
				numero="6";
			}
			if(n7.isSelected()) {
				numero="7";
			}
			if(n8.isSelected()) {
				numero="8";
			}
			if(n9.isSelected()) {
				numero="9";
			}
			if(n10.isSelected()) {
				numero="10";
			}
			if(n11.isSelected()) {
				numero="11";
			}
			if(n12.isSelected()) {
				numero="12";
			}
			if(n13.isSelected()) {
				numero="13";
			}
			if(n14.isSelected()) {
				numero="14";
			}
			if(n15.isSelected()) {
				numero="15";
			}
			if(n16.isSelected()) {
				numero="16";
			}
			if(n17.isSelected()) {
				numero="17";
			}
			if(n18.isSelected()) {
				numero="18";
			}
			if(n19.isSelected()) {
				numero="19";
			}
			if(n20.isSelected()) {
				numero="20";
			}
			if(n21.isSelected()) {
				numero="21";
			}
			if(n22.isSelected()) {
				numero="22";
			}
			if(n23.isSelected()) {
				numero="23";
			}
			if(n24.isSelected()) {
				numero="24";
			}
			if(n25.isSelected()) {
				numero="25";
			}
			if(n26.isSelected()) {
				numero="26";
			}
			if(n27.isSelected()) {
				numero="27";
			}
			if(n28.isSelected()) {
				numero="28";
			}
			if(n29.isSelected()) {
				numero="29";
			}
			if(n30.isSelected()) {
				numero="30";
			}
			if(n31.isSelected()) {
				numero="31";
			}
			if(n32.isSelected()) {
				numero="32";
			}
			if(n33.isSelected()) {
				numero="33";
			}
			if(n34.isSelected()) {
				numero="34";
			}
			if(n35.isSelected()) {
				numero="35";
			}
			if(n0.isSelected()) {
				numero="36";
			}

			if(nRojo.isSelected()) {
				numero="ROJO";
			}
			if(nNegro.isSelected()) {
				numero="NEGRO";
			}
			if(nPar.isSelected()) {
				numero="PAR";
			}
			if(nImpar.isSelected()) {
				numero="IMPAR";
			}
			if(n00.isSelected()) {
				numero="00";
			}
			if(p.getTipoMesa().equals("MesaEuropeaAL")&&(n00.isSelected())) {
				nRojo.setSelected(true);
				numero="";

			}
			if(p.getTipoMesa().equals("MesaClasicaHS")&&((n00.isSelected())||(n0.isSelected()))) {
				nRojo.setSelected(true);
				numero="";

			}
			if(numero.equals("")==false) {
				if (u.getMonedero() - p.getMesa().getPrecioApuesta() >= 0) {
					u.setMonedero(u.getMonedero() - p.getMesa().getPrecioApuesta());
					p.adherirseNumero(numero, u, new Date());
					mc.getC().getUsuarios().remove(u.getNombre());
					mc.getC().getUsuarios().put(u.getNombre(), u);
					Date d=p.getFecha();
					mc.getC().getPartidas().remove(d);
					mc.getC().getPartidas().put(d, p);
					mc.setU(u);
					alerta.setContentText("Tu apuesta se ha a�adido correctamente");		

				}else {

					alerta.setContentText("No tienes suficiente dinero para hacer la apuesta");		

				}


			}
		}

		DineroJug.setText(Float.toString(mc.getU().getMonedero()));
		alerta.showAndWait();


	}


	@FXML
	void MostrarPartidas(ActionEvent event) {
		DineroJug.setText(Float.toString(mc.getU().getMonedero()));
		List<Partida> l=transformarMapaLista(mc.getC().getPartidas()) ;

		partidas = FXCollections.observableList(l);
		tblPartidas.setItems(partidas);

		//He estado probando con esta metodologia para saber el nombre de la clase y como no funcionaba , 
		//cree un atributo String en partida el cual indica el tipo de mesa 
		//Partida p=this.tblPartidas.getSelectionModel().getSelectedItem();
		//System.out.println(p.getClass().getName());

		this.colTipoMesa.setCellValueFactory(new PropertyValueFactory("tipoMesa"));
		this.colPrecioApuesta.setCellValueFactory(new PropertyValueFactory("precio"));
		this.colJugada.setCellValueFactory(new PropertyValueFactory("fecha"));

		tblPartidas.getColumns().setAll(colTipoMesa, colPrecioApuesta,colJugada);


	}


	private List<Partida> transformarMapaLista(Map<Date, Partida> map) {

		List<Partida> lista = new ArrayList<Partida>();

		for (Partida p : map.values()) {
			if(p.isJugado()==false) {
				
			lista.add(p);
			}
		}
		return lista;


	}
	private void closeStage(ActionEvent event) {
		Node source = (Node) event.getSource();
		Stage stage = (Stage) source.getScene().getWindow();
		stage.close();
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub

	}



}

