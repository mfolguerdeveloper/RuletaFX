package es.unex.cum.mdp.sesion10.controlador;

import java.net.URL;
import java.util.Date;
import java.util.ResourceBundle;

import es.unex.cum.mdp.sesion10.modelo.Partida;
import es.unex.cum.mdp.sesion10.modelo.Usuario;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.stage.Stage;

public class CrearMesaControlador implements Initializable {

	

	private MainControlador mc = null;

	public void setM(MainControlador mc) {this.mc = mc;}

	
	@FXML
	private TextField CajaMesa;

	@FXML
	private TextField PrecioApuesta;

	@FXML
	private RadioButton mClasica;

	@FXML
	private ToggleGroup Mesas;

	@FXML
	private RadioButton mEuropea;

	@FXML
	private RadioButton mAmericana;

	@FXML
	void PulsadoCancel(ActionEvent event) {
		closeStage(event);
	}

	@FXML
	void PulsadoOk(ActionEvent event) {
		Alert alerta = new Alert(AlertType.INFORMATION);

		String tipo="";
		Alert alerta2 = new Alert(AlertType.INFORMATION);
		if(mClasica.isSelected()) {
			tipo="MesaClasicaHS";
		}
		if(mEuropea.isSelected()) {
			tipo="MesaEuropeaAL";
		}
		if(mAmericana.isSelected()) {
			tipo="MesaAmericanaHM";
		}
		Date fecha = new Date();
		try {
			
			if(mc.getC().getCaja()-Float.parseFloat(CajaMesa.getText())>=0) {
			Partida p=mc.getC().crearPartida(tipo,fecha,Float.parseFloat(CajaMesa.getText()), Float.parseFloat(PrecioApuesta.getText()));
		
			
			if(mc.getC().getUsuarios().get("prueba")!=null) {
				for(int i=1;mc.getC().getUsuarios().get("prueba").getApuestas().size()<20;i++) {

					if (mc.getC().getUsuarios().get("prueba").getMonedero() - p.getMesa().getPrecioApuesta() >= 0) {
					p.adherirseNumero(String.valueOf(i), mc.getC().getUsuarios().get("prueba"), new Date());
					mc.getC().getUsuarios().get("prueba").setMonedero(mc.getC().getUsuarios().get("prueba").getMonedero() - p.getMesa().getPrecioApuesta());


					}else {

						alerta.setContentText("Por falta de dinero no se han podido a�adir las apuestas del usuario prueba ");		

					}
					
					
					
				}

			}
			alerta2.setContentText("Partida creada correctamente");

			}else {
				alerta2.setContentText("No hay suficiente dinero en el casino para crear esa caja");
			}
		
		}catch(java.lang.NumberFormatException e) {
			
			// alert3.setTitle("No hay fichero!!! ");
			alerta2.setContentText("Error al introducir los caracteres numericos");
			
		}
		alerta2.showAndWait();
		closeStage(event);
		}

	private void closeStage(ActionEvent event) {
		Node source = (Node) event.getSource();
		Stage stage = (Stage) source.getScene().getWindow();
		stage.close();
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {

		CajaMesa.setText("");
		PrecioApuesta.setText("");
		
	}
}

