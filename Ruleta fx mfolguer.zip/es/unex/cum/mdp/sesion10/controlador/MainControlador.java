package es.unex.cum.mdp.sesion10.controlador;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.URL;
import java.util.ResourceBundle;

import es.unex.cum.mdp.sesion10.modelo.Casino;
import es.unex.cum.mdp.sesion10.modelo.Partida;
import es.unex.cum.mdp.sesion10.modelo.Usuario;
import es.unex.cum.mdp.sesion10.modelo.UsuarioNoAutenticado;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class MainControlador implements Initializable {

	private Casino c = null;
	private Usuario u = null;
	@FXML
	private MenuBar menuBar;

	@FXML
	private MenuItem btnSalir;
	@FXML
	private Label txtNombre;

	@FXML
	private Label txtDinero;

	public Usuario getU() {
		return u;
	}

	public void setU(Usuario u) {
		this.u = u;
	}

	public Casino getC() {
		return c;
	}

	public void setC(Casino c) {
		this.c = c;
	}

	@FXML
	void CrearPartida(ActionEvent event) throws IOException {
		Alert alerta = new Alert(AlertType.INFORMATION);
		if (u == null) {
			alerta.setContentText("Debes Iniciar sesion");
			alerta.showAndWait();

		} else {
			if (u.getNick().equals("admin") && u.getPassword().equals("admin")) {
				FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("../vistas/CrearPartidaVista.fxml"));
				Parent parent = fxmlLoader.load();

				// Se crear el controlador de di�logo y se pasa el controlador principal
				CrearMesaControlador dialogController = fxmlLoader.getController();
				dialogController.setM(this);
				// Se establece la escena
				Scene scene = new Scene(parent);

				// Se establece el stage
				Stage stage = new Stage();
				stage.initModality(Modality.APPLICATION_MODAL);
				stage.setScene(scene);
				stage.showAndWait();

			} else {

				alerta.setContentText("Debes ser Administrador ->nick y contrase�a:admin");
				alerta.showAndWait();
			}

		}
	}

	/*
	 * partidas disponibles , apostar, ver informacion de diistintas apuestas a esta
	 * partida
	 */
	@FXML
	void Apostar(ActionEvent event) throws IOException {
		// Alertas
		Alert alerta = new Alert(AlertType.INFORMATION);
		Alert alerta1 = new Alert(AlertType.INFORMATION);
		if (u == null) {
			alerta.setContentText("Debes IniciarSesion antes");
			alerta.showAndWait();
		}
		if ((u.getNick().equals("admin") && u.getPassword().equals("admin"))) {

			alerta.setContentText("Los administradores no pueden apostar");
			alerta.showAndWait();
		}
		if (c.getPartidas().size() == 0) {

			alerta1.setContentText(
					"No hay partidas creadas.Requisitos: ser admin para poder crear partida.     Ser admin->nick y contrase�a:admin");
			alerta1.showAndWait();
		}
		if (c.getCaja() < 36) {

			alerta1.setContentText(
					"No hay lacasitos en la caja del casino para poder jugar,que el administrador ingrese lacasitos al casino");
			alerta1.showAndWait();
		}
		if ((u != null) && (u.getNick().equals("admin") == false && u.getPassword().equals("admin") == false)
				&& (c.getPartidas().size() > 0) && (c.getCaja() >= 36)) {
			// Se establece el fichero fxml que se va a cargar
			FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("../vistas/VerPartidasApostar.fxml"));
			Parent parent = fxmlLoader.load();
			// Se crear el controlador de di�logo y se pasa el controlador principal
			VerPartidasApuestaControlador dialogController = fxmlLoader.getController();
			dialogController.setM(this);

			// Se establece la escena
			Scene scene = new Scene(parent);
			// Se establece el stage
			Stage stage = new Stage();
			stage.initModality(Modality.APPLICATION_MODAL);
			stage.setScene(scene);
			stage.showAndWait();
		}
		txtNombre.setText(u.getNombre());
		if (u.getPassword().equals("admin") == false) {
			txtDinero.setText(Float.toString(u.getMonedero()) + " $");
		} else {
			txtDinero.setText("");

		}

	}

	@FXML
	void Loguearse(ActionEvent event) throws IOException, UsuarioNoAutenticado {

		if (c.getUsuarios().isEmpty()) {
			c.register("admin", "admin", "admin", 0);
			c.register("prueba", "prueba", "prueba", 10000);

		}
		txtNombre.setText("");
		txtDinero.setText("");

		// Se establece el fichero fxml que se va a cargar
		FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("../vistas/IniciarSesionVista.fxml"));
		Parent parent = fxmlLoader.load();
		// Se crear el controlador de di�logo y se pasa el controlador principal
		LoguearseControlador dialogController = fxmlLoader.getController();
		dialogController.setM(this);
		// Se establece la escena
		Scene scene = new Scene(parent);
		// Se establece el stage
		Stage stage = new Stage();
		stage.initModality(Modality.APPLICATION_MODAL);
		stage.setScene(scene);
		stage.showAndWait();
		u = dialogController.getU();
		if (u != null) {
			txtNombre.setText(u.getNombre());/////////////////

			if (u.getPassword().equals("admin") == false) {
				txtDinero.setText(Float.toString(u.getMonedero()) + " $");
			} else {
				txtDinero.setText("");

			}
		}
	}

	@FXML
	void Registrarse(ActionEvent event) throws IOException {
		// Se establece el fichero fxml que se va a cargar
		FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("../vistas/RegistrarseVista.fxml"));
		Parent parent = fxmlLoader.load();

		RegistrarseControlador dialogController = fxmlLoader.getController();
		// Se establece la escena
		Scene scene = new Scene(parent);
		// Se establece el stage
		Stage stage = new Stage();
		stage.initModality(Modality.APPLICATION_MODAL);
		stage.setScene(scene);
		stage.showAndWait();
		// Una vez finalizado, se recupera la pieza (null o un objeto)
		u = dialogController.getU();
		if (u == null) {
			Alert alert3 = new Alert(AlertType.INFORMATION);
			// alert3.setTitle("No hay fichero!!! ");
			alert3.setContentText("Datos incorrectos o incompletos");
			alert3.showAndWait();
		} else {
			Alert alert3 = new Alert(AlertType.INFORMATION);
			// alert3.setTitle("No hay fichero!!! ");
			if (c.register(u.getNick(), u.getNombre(), u.getPassword(), u.getMonedero())) {
				alert3.setContentText("A�adido correctamente, inicie sesion");
			} else {
				alert3.setContentText("El usuario ya existe");
			}
			alert3.showAndWait();
		}
		u = null;
	}

	@FXML
	void Salir(ActionEvent event) {
		Stage stage = (Stage) menuBar.getScene().getWindow();
		stage.close();
	}

	@FXML
	void VerEstadisticasCasino(ActionEvent event) throws IOException {
		// Se establece el fichero fxml que se va a cargar
		Alert alerta = new Alert(AlertType.INFORMATION);
		if (u == null) {
			alerta.setContentText("Debes Iniciar sesion");
			alerta.showAndWait();

		} else {
			FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("../vistas/VerEstadisticas.fxml"));
			Parent parent = fxmlLoader.load();
			// Se crear el controlador de di�logo y se pasa el controlador principal
			VerEstadisticas dialogController = fxmlLoader.getController();
			dialogController.setM(this);
			// Se establece la escena
			Scene scene = new Scene(parent);
			// Se establece el stage
			Stage stage = new Stage();
			stage.initModality(Modality.APPLICATION_MODAL);
			stage.setScene(scene);
			stage.showAndWait();
		}
	}

	@FXML
	void btnGuardarPartida(ActionEvent event) {

	}

	@FXML
	void AbrirPartida(ActionEvent event) {

	}

	/*
	 * Te muestra todas las partidas y eliges de cual quieres verel reparto
	 */
	@FXML
	void VerReparto(ActionEvent event) throws IOException {
		Alert alerta = new Alert(AlertType.INFORMATION);
		if (u == null) {
			alerta.setContentText("Debes Iniciar sesion");
			alerta.showAndWait();

		} else {
			// Se establece el fichero fxml que se va a cargar
			FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("../vistas/VerPartidasVista.fxml"));
			Parent parent = fxmlLoader.load();
			// Se crear el controlador de di�logo y se pasa el controlador principal
			VerPartidasControlador dialogController = fxmlLoader.getController();
			dialogController.setM(this);
			// Se establece la escena
			Scene scene = new Scene(parent);
			// Se establece el stage
			Stage stage = new Stage();
			stage.initModality(Modality.APPLICATION_MODAL);
			stage.setScene(scene);
			stage.showAndWait();
		}
	}

	@FXML
	void GirarRuleta(ActionEvent event) throws IOException {
		Alert alerta = new Alert(AlertType.INFORMATION);
		if (u == null) {
			alerta.setContentText("Debes Iniciar sesion                                          ");
			alerta.showAndWait();

		} else {
			if (u.getNick().equals("admin") && u.getPassword().equals("admin")) {
				// Se establece el fichero fxml que se va a cargar
				FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("../vistas/GirarRuletaVista.fxml"));
				Parent parent = fxmlLoader.load();
				// Se crear el controlador de di�logo y se pasa el controlador principal
				GirarRuletaControlador dialogController = fxmlLoader.getController();
				dialogController.setM(this);
				// Se establece la escena
				Scene scene = new Scene(parent);
				// Se establece el stage
				Stage stage = new Stage();
				stage.initModality(Modality.APPLICATION_MODAL);
				stage.setScene(scene);
				stage.showAndWait();
			} else {

				alerta.setContentText("Debes ser Administrador ->nick y contrase�a:admin");
				alerta.showAndWait();
			}
		}

	}

	/*
	 * lista de apuestas del usuario
	 */
	@FXML
	void MisApuestas(ActionEvent event) throws IOException {

		Alert alerta = new Alert(AlertType.INFORMATION);
		if (u == null) {
			alerta.setContentText("Debes IniciarSesion antes                                      ");
			alerta.showAndWait();
		}
		if ((u.getNick().equals("admin") && u.getPassword().equals("admin"))) {

			alerta.setContentText("Los administradores no pueden apostar ");
			alerta.showAndWait();
		}
		if (u.getApuestas().isEmpty()) {

			alerta.setContentText("No se ha realizado ninguna apuesta  ");
			alerta.showAndWait();
		}

		if ((u != null) && (u.getNick().equals("admin") == false && u.getPassword().equals("admin") == false)
				&& (c.getPartidas().size() > 0) && u.getApuestas().isEmpty() == false) {
			// Se establece el fichero fxml que se va a cargar
			FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("../vistas/ApuestasVista.fxml"));
			Parent parent = fxmlLoader.load();
			// Se crear el controlador de di�logo y se pasa el controlador principal
			VerApuestasControlador dialogController = fxmlLoader.getController();
			dialogController.setM(this);
			// Se establece la escena
			Scene scene = new Scene(parent);
			// Se establece el stage
			Stage stage = new Stage();
			stage.initModality(Modality.APPLICATION_MODAL);
			stage.setScene(scene);
			stage.showAndWait();
		}
	}

	/*
	 * lista de movimientos del usuario
	 */
	@FXML
	void MisMovimientos(ActionEvent event) throws IOException {
		Alert alerta = new Alert(AlertType.INFORMATION);
		if (u == null) {
			alerta.setContentText("Debes IniciarSesion antes                                  ");
			alerta.showAndWait();
		}
		if ((u.getNick().equals("admin") && u.getPassword().equals("admin"))) {

			alerta.setContentText("Los administradores no tienen movimientos");
			alerta.showAndWait();
		}
		if (u.getHistorico().isEmpty()) {

			alerta.setContentText("No se ha realizado ninguna apuesta");
			alerta.showAndWait();
		}

		if ((u != null) && (u.getNick().equals("admin") == false && u.getPassword().equals("admin") == false)
				&& (c.getPartidas().size() > 0) && u.getHistorico().isEmpty() == false) {
			// Se establece el fichero fxml que se va a cargar
			FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("../vistas/MovimientosVista.fxml"));
			Parent parent = fxmlLoader.load();
			// Se crear el controlador de di�logo y se pasa el controlador principal
			VerMoviminetosControlador dialogController = fxmlLoader.getController();
			dialogController.setM(this);
			// Se establece la escena
			Scene scene = new Scene(parent);
			// Se establece el stage
			Stage stage = new Stage();
			stage.initModality(Modality.APPLICATION_MODAL);
			stage.setScene(scene);
			stage.showAndWait();
		}

	}

	/*
	 * Ver todas las Mesas y ver mis sendas apuestas
	 */
	@FXML
	void MisApuestasMesa(ActionEvent event) throws IOException {
		Alert alerta = new Alert(AlertType.INFORMATION);
		if (u == null) {
			alerta.setContentText("Debes IniciarSesion antes                                      ");
			alerta.showAndWait();
		}
		if ((u.getNick().equals("admin") && u.getPassword().equals("admin"))) {

			alerta.setContentText("Los administradores no pueden apostar ");
			alerta.showAndWait();
		}
		if (u.getApuestas().isEmpty()) {

			alerta.setContentText("No se ha realizado ninguna apuesta  ");
			alerta.showAndWait();
		}

		if ((u != null) && (u.getNick().equals("admin") == false && u.getPassword().equals("admin") == false)
				&& (c.getPartidas().size() > 0)) {
			// Se establece el fichero fxml que se va a cargar
			FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("../vistas/MesaApuestasVista.fxml"));
			Parent parent = fxmlLoader.load();
			// Se crear el controlador de di�logo y se pasa el controlador principal
			MesaApuestasControlador dialogController = fxmlLoader.getController();
			dialogController.setM(this);
			// Se establece la escena
			Scene scene = new Scene(parent);
			// Se establece el stage
			Stage stage = new Stage();
			stage.initModality(Modality.APPLICATION_MODAL);
			stage.setScene(scene);
			stage.showAndWait();
		}

	}

	@FXML
	void IngresarDineroCasino(ActionEvent event) throws IOException {
		Alert alerta = new Alert(AlertType.INFORMATION);
		if (u == null) {
			alerta.setContentText("Debes Iniciar sesion                                                ");
			alerta.showAndWait();

		} 
		
		else {
			if (u.getNick().equals("admin") && u.getPassword().equals("admin")) {
				FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("../vistas/DineroCasino.fxml"));
				Parent parent = fxmlLoader.load();
				// Se crear el controlador de di�logo y se pasa el controlador principal
				DineroCasinoControlador dialogController = fxmlLoader.getController();
				dialogController.setM(this);
				// Se establece la escena
				Scene scene = new Scene(parent);
				// Se establece el stage
				Stage stage = new Stage();
				stage.initModality(Modality.APPLICATION_MODAL);
				stage.setScene(scene);
				stage.showAndWait();

			} else {

				alerta.setContentText("Debes ser Administrador ->nick y contrase�a:admin");
				alerta.showAndWait();
			}

		}
	}

	@FXML
	void LlenarMonedero(ActionEvent event) throws IOException {
		Alert alerta = new Alert(AlertType.INFORMATION);
		if (u == null) {
			alerta.setContentText("Debes IniciarSesion antes                                                    ");
			alerta.showAndWait();
		}
		if ((u.getNick().equals("admin") && u.getPassword().equals("admin"))) {

			alerta.setContentText("Los administradores no pueden apostar");
			alerta.showAndWait();
		}

		if ((u != null) && (u.getNick().equals("admin") == false && u.getPassword().equals("admin") == false)) {
			// Se establece el fichero fxml que se va a cargar
			FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("../vistas/LlenarMonederoVista.fxml"));
			Parent parent = fxmlLoader.load();
			// Se crear el controlador de di�logo y se pasa el controlador principal
			LlenarMonederoControlador dialogController = fxmlLoader.getController();
			dialogController.setM(this);

			// Se establece la escena
			Scene scene = new Scene(parent);
			// Se establece el stage
			Stage stage = new Stage();
			stage.initModality(Modality.APPLICATION_MODAL);
			stage.setScene(scene);
			stage.showAndWait();
		}
		if (u != null) {
			txtNombre.setText(u.getNombre());
			if (u.getPassword().equals("admin") == false) {
				txtDinero.setText(Float.toString(u.getMonedero()) + " $");
			} else {
				txtDinero.setText("");

			}
		}
	}

	@FXML
	void EditarMiPerfil(ActionEvent event) throws IOException {
		// Se establece el fichero fxml que se va a cargar

		if (u == null) {
			Alert alerta = new Alert(AlertType.INFORMATION);
			alerta.setContentText("Debes IniciarSesion antes");
			alerta.showAndWait();
		} else {
			// alertas de iniciar sesion
			FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("../vistas/EditarPerfil.fxml"));
			Parent parent = fxmlLoader.load();

			// Se crear el controlador de di�logo y se pasa el controlador principal
			EditarPerfilControlador dialogController = fxmlLoader.getController();
			dialogController.setM(this);
			// Se establece la escena
			Scene scene = new Scene(parent);
			// Se establece el stage
			Stage stage = new Stage();
			stage.initModality(Modality.APPLICATION_MODAL);
			stage.setScene(scene);
			stage.showAndWait();
			if (u != null) {
				txtNombre.setText(u.getNombre());
				if (u.getPassword().equals("admin") == false) {
					txtDinero.setText(Float.toString(u.getMonedero()) + " $");
				} else {
					txtDinero.setText("");

				}
			}
		}

	}

	/*
	 * public void shutdown() { System.out.println("Stop"); try {
	 * d.salvarPiezas("piezas.txt"); SalvarSerializable("datos.dat"); } catch
	 * (IOException e) { Alert alert3 = new Alert(AlertType.ERROR);
	 * alert3.setTitle("Problemas al salvar!!! ");
	 * alert3.setContentText(e.getMessage()); alert3.showAndWait();
	 * 
	 * } }
	 */
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		try {
			c = CargarSerializable("datos.dat");
			c.cargarMovimientos("Movimientos.txt");
			txtNombre.setText("");
			txtDinero.setText("");

		} catch (ClassNotFoundException | IOException e) {

			Alert alert3 = new Alert(AlertType.INFORMATION);
			alert3.setTitle("No hay fichero!!! ");
			alert3.setContentText("El casino funcionar� sin datos");
			alert3.showAndWait();
			c = new Casino();
		}

	}

	public void shutdown() {
		System.out.println("Stop");
		try {

			c.salvarMovimientos("Movimientos.txt");
			SalvarSerializable("datos.dat");
		} catch (IOException e) {
			Alert alert3 = new Alert(AlertType.ERROR);
			alert3.setTitle("Problemas al salvar!!! ");
			alert3.setContentText(e.getMessage());
			alert3.showAndWait();

		}
	}

	public void SalvarSerializable(String nom) throws FileNotFoundException, IOException {

		ObjectOutputStream archivoObjetosSal = new ObjectOutputStream(new FileOutputStream(nom));
		archivoObjetosSal.writeObject(c); // donde XXXX es la inf. a salvar
		archivoObjetosSal.close();
	}

	public Casino CargarSerializable(String nom) throws FileNotFoundException, IOException, ClassNotFoundException {
		ObjectInputStream archivoObjetosEnt = new ObjectInputStream(new FileInputStream(nom));
		c = (Casino) archivoObjetosEnt.readObject();
		archivoObjetosEnt.close();

		return c;
	}

}
