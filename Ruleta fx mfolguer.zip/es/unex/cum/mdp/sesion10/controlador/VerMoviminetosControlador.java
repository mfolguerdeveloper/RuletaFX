package es.unex.cum.mdp.sesion10.controlador;

import java.util.List;

import es.unex.cum.mdp.sesion10.modelo.Movimiento;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

public class VerMoviminetosControlador {

    @FXML
    private TableView<Movimiento> tblMov;

    @FXML
    private TableColumn colNumeroTablero;

    @FXML
    private TableColumn colValor;

    @FXML
    private TableColumn colMonedero;

    @FXML
    private TableColumn colFecha;
    
	private ObservableList<Movimiento> moviminetos;
private MainControlador mc = null;
	
	//Solo el setter, as� se evita que se devuelva
	public void setM(MainControlador mc) {this.mc = mc;}


    @FXML
    void MostrarMoviminetos(ActionEvent event) {
    	 List<Movimiento> l=mc.getU().getHistorico();
    	 moviminetos = FXCollections.observableList(l);
    	 tblMov.setItems(moviminetos);

			//He estado probando con esta metodologia para saber el nombre de la clase y como no funcionaba , 
			//cree un atributo String en partida el cual indica el tipo de mesa 
				//Partida p=this.tblPartidas.getSelectionModel().getSelectedItem();
				//System.out.println(p.getClass().getName());

			this.colNumeroTablero.setCellValueFactory(new PropertyValueFactory("info"));
			this.colValor.setCellValueFactory(new PropertyValueFactory("valor"));
			this.colMonedero.setCellValueFactory(new PropertyValueFactory("monederoActual"));
			this.colFecha.setCellValueFactory(new PropertyValueFactory("fecha"));
			
			tblMov.getColumns().setAll(colNumeroTablero, colValor,colMonedero,colFecha);
    }

}

