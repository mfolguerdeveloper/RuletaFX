package es.unex.cum.mdp.sesion10.controlador;

import java.net.URL;
import java.util.ResourceBundle;

import es.unex.cum.mdp.sesion10.modelo.Usuario;
import es.unex.cum.mdp.sesion10.modelo.UsuarioNoAutenticado;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;

public class EditarPerfilControlador implements Initializable{

	private Usuario u;
	
	
	private MainControlador mc = null;
	public void setM(MainControlador mainControlador) {
		this.mc=mainControlador;

	}

	@FXML
	private TextField nombre;

	@FXML
	private TextField contrase�a;

	@FXML
	private TextField nick;

	@FXML
	private TextField monedero;

	@FXML
	void PulsadoCancel(ActionEvent event) {
		closeStage(event);
	}

	@FXML
	void PulsadoMostrar(ActionEvent event) {
		

		nombre.setText(mc.getU().getNombre());
		contrase�a.setText(mc.getU().getPassword());
		nick.setText(mc.getU().getNick());
		monedero.setText(Float.toString(mc.getU().getMonedero()));
	}

	@FXML
	void PulsadoOk(ActionEvent event) {
		Alert alert3 = new Alert(AlertType.INFORMATION);
		Usuario u=null;

		try {
			u = new Usuario(nick.getText(), nombre.getText(),contrase�a.getText() ,Float.parseFloat(monedero.getText()));
			alert3.setContentText("Datos guardados");		

		} catch (NumberFormatException ex) {
			alert3.setContentText("Error al introducir caracteres numericos");
			closeStage(event);
		
		}
		alert3.showAndWait();
		mc.getC().getUsuarios().remove(u.getNombre());
		mc.getC().getUsuarios().put(u.getNombre(), u);
		mc.setU(u);

		closeStage(event);
	}


	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {

		nombre.setText("");
		contrase�a.setText("");
		nick.setText("");
		monedero.setText("");
	}

	private void closeStage(ActionEvent event) {
		Node source = (Node) event.getSource();
		Stage stage = (Stage) source.getScene().getWindow();
		stage.close();
	}
}

