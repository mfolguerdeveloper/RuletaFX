package es.unex.cum.mdp.sesion10.controlador;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;

public class DineroCasinoControlador {

    @FXML
    private TextField Dinero;

    private MainControlador mc = null;
	public void setM(MainControlador mainControlador) {
		this.mc=mainControlador;

	}
	
    @FXML
    void PulsadoCancel(ActionEvent event) {
		closeStage(event);

    }

    @FXML
    void PulsadoMostrar(ActionEvent event) {
		Dinero.setText(Float.toString(mc.getC().getCaja()));
    }

    @FXML
    void PulsadoOk(ActionEvent event) {

    	Alert alert3 = new Alert(AlertType.INFORMATION);
    	mc.getC().setCaja(Float.parseFloat(Dinero.getText()));
		alert3.setContentText("Dinero actualizado");		

		alert3.showAndWait();

    }
    private void closeStage(ActionEvent event) {
		Node source = (Node) event.getSource();
		Stage stage = (Stage) source.getScene().getWindow();
		stage.close();
	}

}

