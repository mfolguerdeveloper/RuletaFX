package es.unex.cum.mdp.sesion10.controlador;

import java.net.URL;
import java.util.ResourceBundle;

import es.unex.cum.mdp.sesion10.modelo.Usuario;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class RegistrarseControlador implements Initializable {
	@FXML
	private TextField nombre;
	@FXML
	private TextField contrase�a;
	@FXML
	private TextField nick;
	private Usuario u = null;

	public Usuario getU() {
		return u;
	}

	public void setU(Usuario u) {
		this.u = u;
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		nombre.setText("");
		contrase�a.setText("");
		nick.setText("");
	}

	@FXML
	void PulsadoCancel(ActionEvent event) {
		u = null;
		closeStage(event);
	}

	@FXML
	void PulsadoOk(ActionEvent event) {
		
			u = new Usuario(nick.getText(), nombre.getText(),contrase�a.getText() ,0);
			
			closeStage(event);
		
	}

	private void closeStage(ActionEvent event) {
		Node source = (Node) event.getSource();
		Stage stage = (Stage) source.getScene().getWindow();
		stage.close();
	}
}
