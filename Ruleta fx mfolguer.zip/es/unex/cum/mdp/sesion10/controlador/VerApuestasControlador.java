package es.unex.cum.mdp.sesion10.controlador;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

import es.unex.cum.mdp.sesion10.modelo.Apuesta;
import es.unex.cum.mdp.sesion10.modelo.Partida;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

public class VerApuestasControlador  implements Initializable {

    @FXML
    private TableView<Apuesta> tblPart;

    @FXML
    private TableColumn colNumeroTablero;

    @FXML
    private TableColumn colValor;

    @FXML
    private TableColumn colFecha;
    
    @FXML
    private TableColumn colTipoMesa;
    
    @FXML
    private TableColumn colResultado;

    
	private ObservableList<Apuesta> apuestas;

	public Partida p;
	public Partida getP(){
		return p;
	}
	public void setP(Partida p){
		this.p=p;
	}
	private MainControlador mc = null;
	
	//Solo el setter, as� se evita que se devuelva
	public void setM(MainControlador mc) {this.mc = mc;}

    @FXML
    void MostrarApuestas(ActionEvent event) {
    	 List<Apuesta> l=mc.getU().getApuestas() ;
    	 apuestas = FXCollections.observableList(l);
    	 tblPart.setItems(apuestas);

			//He estado probando con esta metodologia para saber el nombre de la clase y como no funcionaba , 
			//cree un atributo String en partida el cual indica el tipo de mesa 
				//Partida p=this.tblPartidas.getSelectionModel().getSelectedItem();
				//System.out.println(p.getClass().getName());

			this.colNumeroTablero.setCellValueFactory(new PropertyValueFactory("ntValor"));
			this.colValor.setCellValueFactory(new PropertyValueFactory("valor"));
			this.colFecha.setCellValueFactory(new PropertyValueFactory("fecha"));
			this.colTipoMesa.setCellValueFactory(new PropertyValueFactory("tipoMesa"));
			this.colResultado.setCellValueFactory(new PropertyValueFactory("ganada"));
			
			tblPart.getColumns().setAll(colNumeroTablero,colTipoMesa, colValor,colFecha,colResultado);
    }
    @Override
	public void initialize(URL url, ResourceBundle rb) {
		
		

	}

}

