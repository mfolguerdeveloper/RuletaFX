package es.unex.cum.mdp.sesion10.controlador;

import java.net.URL;
import java.util.ResourceBundle;

import es.unex.cum.mdp.sesion10.modelo.Partida;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class VerRepartoControlador  implements Initializable{

	private Partida p;
    
	private VerPartidasControlador vp;
	
	public void setVP(VerPartidasControlador vp) {
		this.vp=vp;
	}
	
	@FXML
    private Label caja;

    @FXML
    private Label recaudacion;

    @FXML
    private Label resultado;

    @FXML
    private Label NumApuestas;

    @FXML
    private Label NumNumero;

    @FXML
    private Label NumColor;

    @FXML
    private Label NumPI;

    @FXML
    private Label repartoNumero;

    @FXML
    private Label repartoColor;

    @FXML
    private Label repartoPI;

    @FXML
    void PulsadoOk(ActionEvent event) {
		closeStage(event);
    }
    private void closeStage(ActionEvent event) {
		Node source = (Node) event.getSource();
		Stage stage = (Stage) source.getScene().getWindow();
		stage.close();
	}
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		



		
	}
	@FXML
    void MostrarReparto(ActionEvent event) {
		p=vp.getP();
		caja.setText(Float.toString(p.getReparto().getCaja()));
		recaudacion.setText(Float.toString(p.getReparto().getRecaudacion()));
		resultado.setText(Float.toString(p.getReparto().getResultado()));
		NumApuestas.setText(Integer.toString(p.getReparto().getNumApuestas()));
		NumNumero.setText(Integer.toString(p.getReparto().getNumNumero()));
		NumColor.setText(Integer.toString(p.getReparto().getNumColor()));
		NumPI.setText(Integer.toString(p.getReparto().getNumPI()));
		repartoNumero.setText(Float.toString(p.getReparto().getRepartoNumero()));
		repartoColor.setText(Float.toString(p.getReparto().getRepartoColor()));
		repartoPI.setText(Float.toString(p.getReparto().getRepartoPI()));
    }

}

